import Foundation
import simd

/// Current-frame triangles plus a bounded, short-lived display point cloud.
struct SurfaceMesh {
    var vertices: [SIMD3<Float>] = []
    /// Independent dense samples; wireframe decimation must not reduce cloud coverage.
    var pointCloud: [SIMD3<Float>] = []
    var triangles: [Int32] = []
    static let empty = SurfaceMesh()

    /// Only vertices belonging to current triangles can trigger the mesh cue.
    /// Historical display points and isolated vertices never trigger it.
    func nearestTrianglePoint(to origin: SIMD3<Float>, accepting: (SIMD3<Float>) -> Bool = { _ in true }) -> SIMD3<Float>? {
        var nearest: SIMD3<Float>?
        var distance = Float.infinity
        for index in Set(triangles) {
            guard index >= 0, Int(index) < vertices.count else { continue }
            let point = vertices[Int(index)]
            guard accepting(point) else { continue }
            let d = simd_distance(point, origin)
            if d.isFinite && d > 0 && d < distance { nearest = point; distance = d }
        }
        return nearest
    }

    static func connect(points: [SIMD3<Float>?], columns: Int, rows: Int) -> SurfaceMesh {
        guard columns > 1, rows > 1, points.count == columns * rows else { return .empty }
        var mesh = SurfaceMesh()
        var indices = [Int32](repeating: -1, count: points.count)
        for (i, p) in points.enumerated() {
            if let p { indices[i] = Int32(mesh.vertices.count); mesh.vertices.append(p) }
        }
        func append(_ a: Int, _ b: Int, _ c: Int) {
            guard let pa = points[a], let pb = points[b], let pc = points[c],
                  simd_distance(pa, pb) < 0.20, simd_distance(pb, pc) < 0.20,
                  simd_distance(pc, pa) < 0.20 else { return }
            mesh.triangles += [indices[a], indices[b], indices[c]]
        }
        for y in 0..<(rows - 1) {
            for x in 0..<(columns - 1) {
                let a = y * columns + x, b = a + 1, c = a + columns, d = c + 1
                append(a, b, c); append(b, d, c)
            }
        }
        return mesh
    }
}

/// Display-only short-lived world-space samples. Never feeds obstacle selection/audio.
/// Inspired by Apple's multi-frame scene-depth point-cloud example; no copied code.
struct SurfacePointHistory {
    private struct Key: Hashable {
        let x: Int, y: Int, z: Int
    }
    private struct Sample {
        let point: SIMD3<Float>
        let frameID: Int
    }
    private struct Batch {
        let keys: [Key]
        let timestamp: TimeInterval
        let frameID: Int
        var cursor = 0
    }
    let lifetime: TimeInterval
    let capacity: Int
    private let voxelSize: Float = 0.005
    private var samples: [Key: Sample] = [:]
    private var batches: [Batch] = []
    private var sequence = 0
    private var lastTimestamp: TimeInterval?

    init(lifetime: TimeInterval = 0.8, capacity: Int = 120_000) {
        self.lifetime = max(0, lifetime)
        self.capacity = max(1, capacity)
    }

    mutating func reset() {
        samples.removeAll(keepingCapacity: true)
        batches.removeAll(keepingCapacity: true)
        lastTimestamp = nil
    }

    mutating func merge(_ points: [SIMD3<Float>], timestamp: TimeInterval) -> [SIMD3<Float>] {
        guard timestamp.isFinite else { reset(); return [] }
        if let previous = lastTimestamp, timestamp < previous || timestamp - previous > lifetime {
            reset()
        }
        lastTimestamp = timestamp
        sequence += 1
        while let first = batches.first, timestamp - first.timestamp > lifetime {
            discardOldestBatch()
        }
        var keys: [Key] = []
        keys.reserveCapacity(points.count)
        for p in points {
            // Store measured positions, never voxel centers or interpolated geometry.
            guard p.x.isFinite, p.y.isFinite, p.z.isFinite,
                  abs(p.x) < 10_000, abs(p.y) < 10_000, abs(p.z) < 10_000 else { continue }
            let key = Key(x: Int(floor(p.x / voxelSize)), y: Int(floor(p.y / voxelSize)),
                          z: Int(floor(p.z / voxelSize)))
            if samples[key]?.frameID != sequence { keys.append(key) }
            samples[key] = Sample(point: p, frameID: sequence)
        }
        batches.append(Batch(keys: keys, timestamp: timestamp, frameID: sequence))
        // FIFO expiration/capacity eviction avoids sorting the whole cloud every frame.
        while samples.count > capacity, !batches.isEmpty {
            discardOldestPoint()
        }
        while batches.count > 32 { discardOldestBatch() }
        return samples.values.map(\.point)
    }

    private mutating func discardOldestPoint() {
        guard !batches.isEmpty else { return }
        if batches[0].cursor < batches[0].keys.count {
            let key = batches[0].keys[batches[0].cursor]
            if samples[key]?.frameID == batches[0].frameID { samples.removeValue(forKey: key) }
            batches[0].cursor += 1
        }
        if batches[0].cursor >= batches[0].keys.count { batches.removeFirst() }
    }

    private mutating func discardOldestBatch() {
        guard !batches.isEmpty else { return }
        let batch = batches.removeFirst()
        for key in batch.keys.dropFirst(batch.cursor) {
            if samples[key]?.frameID == batch.frameID { samples.removeValue(forKey: key) }
        }
    }
}


/// One shared decision for the measured mesh beep and cell playback.
/// A quiet 1–3 m cell must not suppress the mesh cue; sub-1 m danger takes over.
enum MeshCuePolicy {
    static func isFresh(timestamp: Double, now: Double) -> Bool {
        now.isFinite && timestamp.isFinite && now >= timestamp && now - timestamp < 0.4
    }
    static func usesMesh(timestamp: Double?, now: Double, nearestActiveDistance: Float?) -> Bool {
        guard let timestamp, isFresh(timestamp: timestamp, now: now) else { return false }
        return !(nearestActiveDistance.map { $0 < 1 } ?? false)
    }
    static func interval(distance: Float) -> Double {
        ProximityRhythm.interval(distance: distance)
    }
    static func gain(distance: Float) -> Float {
        0.18 - (min(6, max(1, distance)) - 1) * 0.012
    }
}
