# EchoSpace

SwiftUI iPhone app, iOS 17+, designed for iPhone 14 Pro Max with LiDAR and AirPods. The offline Core ML model adds about 50 MB and is excluded from Git. Before building, restore it from this directory with `python3 Scripts/fetch_depth_model.py` (internet required for this one-time download). The script fetches a pinned revision and verifies file sizes and SHA-256 checksums. No inference server or API key is needed at runtime. Then open `EchoSpace.xcodeproj`.


## Recording stability — v9

A small recording-focused update: routine route/category/override changes no
longer stop AR scanning. The audio engine is restarted only if needed. Real
system interruptions suspend playback while scanning continues; when the system
marks the interruption resumable, playback is reactivated without another Start.
Non-resumable interruptions, audio-service resets, recovery errors and backgrounding
still require a fresh Start. Head calibration is invalidated when an actual audio
device is added/removed, not merely on a category change.

Camera delegate snapshots use a locked single-slot mailbox: when UI work falls
behind, newer snapshots replace pending ones rather than creating a backlog of
large point clouds. Depth processing remains at 15 Hz; geometry publication is
limited to 10 Hz, with the camera preview still targeting 30 fps. Display history
is capped at 120,000 points instead of 180,000. Camera model submissions are at
most once per 0.8 seconds (1.25 Hz), instead of 0.5 seconds (2 Hz). Point lifetime,
proximity cadence, zone thresholds, help and head calibration are unchanged.
The 0.4-second validity threshold remains; demo heartbeat continues to cover
expired-data gaps instead of pretending old measurements are current.

Validated: native regression suite, 10,000 stalled-consumer submissions coalesced
to one pending delivery, concurrent mailbox producers, and unsigned iPhone build.
These checks do not reproduce physical iPhone screen recording, thermal pressure
or audio-route changes. Confirm **RECORDING STABILITY v9** and record a short
speaker-output clip before the demo; verify Stop stays active, the labeled demo
heartbeat bridges missing-data gaps, and live center warnings resume afterward.

## Demo continuity — v8 (enabled by default)

**Demo continuous sound** fills audio gaps with a centered, non-spatial 400 Hz,
180 ms beep at gain 0.12, at most once per second. This is an explicitly labeled
presentation heartbeat, **not a detection, measured distance or direction cue**.
It starts even before the first depth result and continues when depth is missing
or when a scene has no eligible obstacle. The camera session still scans normally.
Expired measurements are cleared; no stale obstacle is replayed as a new result.

Every real obstacle pulse, continuous near tone, Axis Test or motion alert resets
the heartbeat budget. Actual cues take precedence and stop a playing heartbeat.
The on-screen **DEMO TONE · Not an obstacle alert** identifies the fallback.
Disable the toggle to restore the previous silent-when-no-valid-target behavior.
Center/side thresholds, proximity rhythm, head alignment and the help dialog are
unchanged. The demo heartbeat intentionally bypasses spatial head orientation
because it represents no world-space target.

Stop, backgrounding, an audio interruption, route loss or a stalled/suspended
app can still stop output; this feature cannot guarantee uninterrupted sound
through operating-system interruptions. A missing-data status is not a paused
scanner. The timer and heartbeat keep running as long as the app/audio engine run.

Validated locally: shared heartbeat scheduler tests for ten seconds of missing
data, actual-cue priority, disabled mode and interval limits; all existing native
checks; unsigned iPhone build. On device, confirm **DEMO CONTINUITY v8**, cover the
camera briefly, and verify the centered heartbeat plus demo label. Uncover and
verify measured spatial cues take over. Turn the toggle off and verify silence
without targets; Stop must stop both. Repeat head calibration and movement/help
checks. These physical-device continuity checks remain to be performed.

## Headphone / camera calibration — HEAD ALIGN v7

Based on saved user-approved v6 commit `6716bd9` / tag
`approved-continuous-scan-v6`, on branch `feature/headphone-calibration`.
Center-third detection, side 1 m threshold, rhythm, motion warning/help workflow,
depth calibration and point rendering are unchanged. This iteration adds
**horizontal head turning**, preserving natural binaural HRTF rather than muting
one ear. It is not full pitch/roll head tracking.

### Use on a real iPhone

1. Build/run this same project, confirm **HEAD ALIGN v7**, wear motion-capable
   headphones and select them as the Bluetooth audio output. Start scanning.
2. Allow Motion permission if asked. Once headphone samples are available, face
   forward with the portrait phone's rear camera pointing in the same direction.
   Hold both head and phone still, then press **Calibrate Headphones & Camera**. Calibration
   requires a normally tracked camera, fresh nearly simultaneous samples and
   low angular motion. The app cannot itself verify that your eyes face the camera
   direction; that alignment is the user's calibration step.
3. A calibrated status and signed head-vs-camera angle appear. Keep your head
   still and rotate the phone left to scan a target: it should sound to your left.
   Turn your head toward the same world target: it should move toward the center.
   Keep the phone still and turn your head left: its forward target should sound
   on your right. Check slow movements first and also repeat Axis Test.
4. **Recalibrate** establishes a new forward direction; **Use Phone Direction** returns
   to v6 camera-relative listening without changing detection or stopping scanning.
5. Stop/Start, audio-route interruptions and earbud source changes invalidate the
   reference. Headphone samples older than 350 ms, unavailable motion or denied
   permission fall back to the phone pose and display a status. A returned stream
   requires explicit recalibration, rather than silently reusing the old reference.

### Implementation and practical limits

`HeadphoneMotionMonitor.swift` uses Apple's `CMHeadphoneMotionManager`, checks
availability/authorization, tracks source changes, rejects stale/out-of-order
samples, and generation-checks callbacks after stop/restart. Camera and headphone
calibration samples must be within 150 ms, camera data younger than 250 ms and
both angular speeds below 0.35 rad/s. Unsupported headphones retain existing
phone-relative sound; calibration is disabled until supported fresh input arrives.

`HeadPoseAlignment.swift` selects a well-conditioned headphone local axis and
projects quaternion-rotated vectors onto Core Motion's horizontal reference
plane (+Z vertical). It measures heading change from the calibration reference
and maps that yaw around AR world's +Y. Thus an arbitrary initial sensor heading
and headphone axis mounting do not become the listener's absolute heading.
Calibration uses the camera's horizontal forward vector. This horizontal-only
method does not model looking up/down or rolling the head; large tilt can make
heading unavailable, requiring recalibration. Long-term inertial yaw drift and
AR relocalization may also require a fresh alignment. There is no prediction to
compensate Bluetooth motion/audio latency.

`SpatialAudioEngine.listenerPose()` is the only listener-pose provider. After
calibration, its rotation comes from head heading and its position remains the
camera position (a chest-to-head approximation, not measured head translation).
The audio environment receives -Z forward and +Y up as vector orientation; no
listener Euler angles or image-column-to-pan mapping are used. Moving the phone
must never be multiplied into the calibrated head heading again. Sources remain
at measured AR world coordinates. Inference and center-zone selection still use
the camera, so turning the head does not change which objects get detected.

Validation: unsigned iPhone build; existing detector/audio/motion regressions;
synthetic tests of all three user scenarios, nonzero initial camera/head heading,
quaternion sign equivalence, translation, reset, invalid attitudes and staleness.
These are mathematical and compilation checks. Real headphone sign convention,
latency, availability, drift and perceived direction require the on-device steps
above. No real-headphone test has been performed by the agent.

References: [Apple headphone motion manager](https://developer.apple.com/documentation/coremotion/cmheadphonemotionmanager),
[Apple Core Motion reference frames](https://developer.apple.com/documentation/coremotion/cmattitudereferenceframe),
[WWDC23: headphone availability, permission and sensor-source switching](https://developer.apple.com/videos/play/wwdc2023/10179/).

## Current instability behavior — CONTINUOUS SCAN v6

Motion warnings no longer block frame reception, hide valid geometry, disable
model inference or silence current obstacle measurements. A debounced unstable
transition produces the existing warning sound/haptic and an English alert:
“Do you need help?”. “Not Now” dismisses it. “Get Help” opens the iOS share sheet
with a help message; the user chooses a recipient/app and confirms sending.
No contacts, location or message are sent automatically. Scanning continues while
the in-app alert is shown. Repeated transitions have a three-second alert cooldown.

ARKit limited tracking now processes fresh LiDAR measurements instead of
rejecting the entire frame, and the status explicitly says measurements may
drift. Missing tracking/depth and data older than 0.4 seconds still cannot produce
new directional obstacle measurements: targets expire while the AR session,
audio engine and inference service stay running, ready for the next valid frame.
No “direction cues paused” mode or manual restart is introduced by these cases.
Old inference results cannot restore a target while current depth is unavailable.

Stop, backgrounding, unrecoverable AR failures and system audio interruptions
still end the run. Merely becoming inactive (such as an in-app dialog) no longer
ends it. Axis Test is cancelled if fresh measurements are lost. Center/side zone
rules and v4 distance cadence are unchanged. This section supersedes the earlier
motion-pauses-geometry/audio behavior recorded below.

Acceptance on iPhone: confirm **CONTINUOUS SCAN v6**, trigger a brief movement
warning, and verify the help alert, current-data obstacle cues and scanning
continue. Dismiss and repeat after stability recovers; try the help share sheet
without sending. Cover/uncover the camera to check waiting/recovery with no Start
required. Tracking accuracy during motion and system dialog/audio behavior need
this physical-device check; a successful compile does not establish them.

## Current warning zones — CENTER ALERT v5

The portrait camera preview is divided into three equal vertical strips with
visible dashed boundaries. The middle third gets early measured-mesh warnings
using the v4 rhythm (about one second at 3.6 m, faster when approaching).
The left/right thirds retain visible mesh and points but only trigger LiDAR
warnings at or within 1 m. The camera model's distant estimates are also
restricted to the middle third; its existing calibration/corridor checks remain.
This supersedes the earlier all-mesh warning policy described in the history below.

The ARSCNView reports its actual layout size. ARKit's portrait display transform
and projectPoint use this size, so filtering follows the displayed aspect-fill
crop, not raw landscape image columns or the separate 5x2 diagnostic grid.
All audio sources remain unprojected world coordinates. Per-cell eligible samples
are collected independently from display minima so a silent side sample cannot
hide a center sample in the same diagnostic cell. Inactive side distances can
still appear in the debug grid without making sound.

Device check: install and confirm **CENTER ALERT v5**. Keep the same object at
3–4 m and aim it into the middle third: expect a target marker and early beep.
Turn slowly to move it into either side third: early sound should stop after the
current cue/data update. With a sighted helper, bring a side object within 1 m
and confirm the near cue returns. Side-only mesh at >1 m should remain visible
and quiet. Test with Camera far preview both off and on. Axis Test and motion
alerts intentionally remain independent of these obstacle zones.

Unsigned iPhone compilation and native regression checks pass: zone boundaries,
side thresholds, portrait coordinate rotation, independent display/cue samples,
and side-only triangle rejection. Real iPhone crop alignment and perceived
sound still need the device check above.

## Camera surface demo and movement alerts

The live camera panel now shows a cyan triangle wireframe built from confident, current-frame LiDAR samples, with dense cyan points enabled by default. It visualizes nearby walls and obstacle surfaces, not body landmarks or object names. The display combines confident measurements from the most recent 0.8 seconds, deduplicated in 5 mm world-space voxels and capped at 180,000 display points. It keeps measured positions rather than snapping to voxel centers. Moving the camera slightly can add real samples from other viewpoints; it cannot invent unseen surfaces. Moving objects can leave brief trails until old samples expire. This is not a persistent complete-chair model. The display range is axial depth up to 4 m; LiDAR audio remains restricted to the nearest two cells within 3 m radial distance. The separate experimental camera preview described below can provide a distant cue. Orange markers and meter labels locate those active cells; markers turn red below 0.5 m.

- **Wireframe** and **Points** are on by default. Wireframe keeps points enabled; turn Wireframe off to control Points separately. Dense point rendering uses every confident depth pixel at the usual 256 × 192 resolution (up to 49,152 points), independently of the sparse triangle mesh. Larger maps are decimated and capped. The live point count reports the recent merged display cloud, not percent completion, measurement precision, or the number of points on one object. Orange sound-target markers are separate, smaller markers.
- Camera imagery and world geometry use the same ARSession through ARSCNView, preserving portrait/world alignment.
- Surfaces use a bounded sample grid (about 3,072 points at 256 × 192 input); triangle history never accumulates; point history expires after 0.8 seconds. Triangles with any edge of 20 cm or greater are omitted to reduce connections across discontinuities. This heuristic can leave holes and does not guarantee recognition of openings or hazards.
- This is a live depth-derived surface, not a persistent ARMeshAnchor reconstruction. It intentionally disappears when confidence/tracking is lost or data becomes stale. Point history also resets on Start/Stop and motion-warning transitions; it never feeds obstacle detection or audio.
- Core Motion runs at 50 Hz. Rotation above 2.8 rad/s or gravity-free acceleration above 0.9 g for at least 120 ms triggers a warning. It requires 900 ms below both 1.2 rad/s and 0.35 g to recover. These prototype thresholds need chest-mounted device tuning.
- A warning pauses direction sounds and clears surface/obstacle overlays, emits a haptic and a short two-note non-directional alert, and shows **Hold phone steady**. Alerts have a three-second cooldown. Audio and overlays resume only after stability and a fresh, normally tracked depth frame.
- AR tracking failure and stale-depth checks remain independent of motion sensing. If the motion sensor is unavailable, the UI explicitly says so. Start/Stop and backgrounding stop sensor updates; samples from before a new Start are rejected.

New files: `CameraSceneView.swift`, `SurfaceMesh.swift`, `MotionMonitor.swift`, and `MotionStability.swift`. Camera and motion usage strings are in Info.plist. The previous snapshot in the parent `snapshots` folder is retained; touchmap is unchanged.

### On-device demo check

1. Run on your LiDAR iPhone, wear AirPods, and tap Start. Confirm the camera picture appears.
2. Aim at a wall and table 0.5–3 m away. Cyan lines should lie on visible surfaces; turn Points on and check the dots. Move gently sideways to check camera/geometry alignment. No permanent room map is expected.
3. Bring two obstacles into different grid cells and check their world-anchored orange markers, distances, and audio. Use Axis Test from the starting pose to verify directions.
4. While stationary, briefly move the phone briskly without dropping it. Check the warning banner, short alert, haptic, and paused obstacle cues. Hold steady for about a second; confirm fresh cues return. Compare with normal walking and slow turning to check false alarms.
5. Repeat Start/Stop, toggle both visual modes, scroll while audio plays, switch apps, and disconnect/reconnect AirPods. No old geometry or continuous tone should remain after Stop or tracking loss.
6. Run for 10 minutes and inspect Xcode's memory/CPU gauges and phone temperature. This duration test and real-device frame rate have **not** been verified here.

Validation: unsigned iPhone Debug compilation passed. Native checks passed for mesh holes, discontinuity rejection, index bounds across 500 synthetic frames, motion spike rejection, sustained rotation/acceleration, hysteresis recovery, and the original coordinate/audio tests. The synthetic loop is not a substitute for full app/device stress testing.

## Build and run on your iPhone

1. Install/open Xcode 15 or newer, with an iOS SDK that supports the iOS version on your phone. This project was compiled with Xcode 27.0 using the iPhoneOS SDK, with an iOS 17.0 deployment target.
2. Open `EchoSpace.xcodeproj`. Choose the **EchoSpace** scheme.
3. In **Xcode → Settings → Accounts**, add your Apple Account if necessary.
4. In the project navigator, click the blue **EchoSpace** project, select **TARGETS → EchoSpace → Signing & Capabilities**, enable **Automatically manage signing**, and select your **Team** (a Personal Team can be used). Change `com.example.EchoSpace` to a unique bundle identifier, for example `com.yourname.EchoSpace`.
5. Connect the iPhone 14 Pro Max to the Mac by cable. Unlock it, tap **Trust** when prompted, and allow Xcode to finish pairing/device preparation. On iPhone enable **Settings → Privacy & Security → Developer Mode**, restart if requested, and confirm Developer Mode. If the setting is absent, first pair through Xcode's **Window → Devices and Simulators**.
6. Select your actual iPhone in Xcode's run-destination menu, next to the EchoSpace scheme. Do not select a simulator or “Any iOS Device”.
7. Press **⌘R** (Product → Run). If iOS requests developer trust, use **Settings → General → VPN & Device Management** to trust your development identity, then run again.
8. Connect/wear both AirPods and select them as the iPhone audio output. Set a modest media volume. For axis verification, turn system **Spatial Audio / Spatialize Stereo** to **Off**, if that control is available in Control Center's expanded volume control; EchoSpace already renders binaural HRTF. Also ensure **Settings → Accessibility → Audio & Visual → Mono Audio** is off and balance is centered.
9. Hold the phone upright in portrait against your chest, top edge up, rear camera facing forward and unobstructed. Tap **Start**, allow Camera access, and wait for **LiDAR active**. The output name should show your AirPods. Opening Control Center or leaving the app pauses sensing; tap Start again after returning.
10. Stay at the starting position and face straight ahead. Tap **Axis Test**. It replaces obstacle sounds with a 700 Hz tone at **LEFT**, **RIGHT**, and **AHEAD**, two seconds each, anchored one meter from the first valid camera pose after Start. Obstacle sounds resume afterward. If you moved since starting, Stop then Start to establish a fresh origin.

Apple references: [running on a device](https://developer.apple.com/documentation/xcode/running-your-app-on-simulated-or-physical-devices), [AirPods spatial audio controls](https://support.apple.com/en-ke/guide/airpods/dev00eb7e0a3/web).

## Files and behavior

- `DepthSampler.swift`: ARWorldTrackingConfiguration with smoothedSceneDepth, serial delegate processing capped at 15 Hz. Reads every depth pixel with medium/high confidence, respecting buffer row strides. Uses ARFrame.displayTransform for a full-image portrait 5 × 2 grid, taking the minimum valid axial depth per cell. Unprojects the winning original sensor pixel and computes radial distance from the camera in meters.
- `ObstacleModel.swift`: ten cells, world positions and radial distances; selects only the nearest two valid cells at or below 3 m. Includes pure coordinate math.
- `SpatialAudioEngine.swift`: AVAudioEngine, AVAudioEnvironmentNode, ten mono AVAudioPlayerNodes with HRTFHQ and an additional isolated test player. Playback audio session; stereo environment output. Single listenerPose() provider. Updates source positions directly in world coordinates. A 10 ms scheduling timer drives clicks; sub-0.5 m tones loop continuously. Tracking invalidation or depth updates older than 400 ms silence audio.
- `SoundDesign.swift`: mono synthesized 300 Hz body and 1200 Hz head clicks with short attack/decay envelopes. Shared distance mapping: 3.6 m and beyond → 1 second, 3 m → 0.9 seconds, 2 m → 0.65 seconds, 1 m → 0.4 seconds, 0.5 m → 0.1 seconds. Distant cells share the current distance interval, and per-cell cooldown survives selection changes. Below 0.5 m → continuous tone. Distant gain is reduced (0.045 at 3 m, 0.07 at 2 m), rising to 0.24 at 1 m and 0.36 at 0.5 m; automatic distance attenuation rolloff is disabled so rhythm remains the primary cue.
- `AppController.swift`: permissions, lifecycle, session start/stop, audio interruption and route-change handling. Captures the starting pose on the first normally tracked frame. Route changes require tapping Start again.
- `ContentView.swift`: large accessible Start/Stop button, portrait debug grid, active-cell highlights, nearest active XYZ world coordinates, output route, and Axis Test.
- `Info.plist`: camera permission text, portrait-only orientation and ARKit requirement. LiDAR support is additionally checked at runtime.

## Sound/camera alignment

The sensor depth map is landscape regardless of the portrait UI. Grid labels never become audio pan values.

For sensor pixel `(u, v)`, axial depth `d`, and intrinsics scaled from image resolution to depth resolution:

```
cameraPoint = ((u - cx) * d / fx, -(v - cy) * d / fy, -d, 1)
worldPoint  = frame.camera.transform * cameraPoint
```

The raw ARCamera transform has a landscape-oriented basis. Therefore using its raw +Y as listener up in portrait would roll the audio frame by 90°. The implementation explicitly uses `inverse(camera.viewMatrix(for: .portrait))` as the **listener camera transform**. It has the same camera origin and forward direction, but portrait-adjusted right/up axes. `listenerVectorOrientation` receives **forward = −Z** and **up = +Y** of this transform; no Euler angles are used. Raw sensor transform is retained for depth unprojection.

This is an intentional correction to the literal raw-transform-Y request, needed to achieve physical left/right with the phone upright. See Apple's [camera transform convention](https://developer.apple.com/documentation/arkit/arcamera/transform) and [listener vector orientation](https://developer.apple.com/documentation/avfaudio/avaudioenvironmentnode/listenervectororientation).

The axis test uses that same portrait basis at session start: `origin − right`, `origin + right`, `origin + forward`. These three positions stay fixed in world space. The listener continues following the live camera while the test plays. Headphone heading is now calibrated into this AR world frame inside listenerPose(); raw uncalibrated headphone attitude is never substituted directly.

## Verification

Completed locally:

- Unsigned generic iPhone Debug build: **BUILD SUCCEEDED**.
- Native Swift checks for −Z forward, image +Y inversion, rotation and translation into world space, nearest-two selection, 3 m cutoff, empty-frame clearing, pulse-rate endpoints, and finite mono synthesis: **PASS**.

Commands from this directory:

```sh
xcodebuild -project EchoSpace.xcodeproj -scheme EchoSpace -configuration Debug -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath /tmp/EchoSpaceBuild CODE_SIGNING_ALLOWED=NO build
xcrun swiftc -module-cache-path /tmp/EchoSpaceSwiftCache EchoSpace/ObstacleModel.swift EchoSpace/SoundDesign.swift EchoSpace/SurfaceMesh.swift EchoSpace/MotionStability.swift EchoSpace/VisualDepthCalibration.swift EchoSpace/HeadPoseAlignment.swift EchoSpace/LatestValueMailbox.swift Tests/main.swift -o /tmp/EchoSpaceChecks
/tmp/EchoSpaceChecks
```

Still requires physical device testing:

1. Confirm axis test is physically left, right, ahead through AirPods, with your head facing the same direction as the phone.
2. Place an obstacle in each portrait grid region; verify its highlighted cell and perceived direction agree. Upper/lower regions should differ in pitch.
3. Introduce three nearby obstacles in different cells; confirm no more than two highlights/sources. With Camera far preview off, move all beyond 3 m; confirm silence. Unknown/low-confidence cells display a dash and remain silent.
4. Check cadence near 3 m (0.9-second interval), 2 m (0.65-second interval), 1 m (2.5 Hz), and 0.5 m (10 Hz); below 0.5 m it becomes a tone, subject to the sensor producing a confident near-range measurement.
5. Disconnect AirPods, lock the phone, or interrupt tracking; confirm audio stops. Restart explicitly afterward.

## Limits

This is a prototype assistive cue, not a validated mobility aid; test stationary with a sighted helper and keep using your established mobility aid. “Head” and “body” mean top/bottom camera-image regions, not semantic obstacle classification or actual height estimates. Minimum depth can jitter, even after confidence filtering. LiDAR and smoothed depth have blind spots and latency; AirPods add audio latency. No detection means no sound, which does not establish that an area is safe. Before calibration, sound follows the phone. HEAD ALIGN v7 adds horizontal headphone heading after explicit calibration; pitch/roll and independently measured head translation are not tracked. Simulator cannot verify LiDAR, physical direction, or AirPods latency.

### Point-density iteration references

The display-only short-term accumulation approach follows the multi-frame point-cloud concept described in [Apple’s Explore ARKit 4](https://developer.apple.com/videos/play/wwdc2020/10611/) and [Apple’s scene-depth point-cloud sample](https://developer.apple.com/documentation/arkit/displaying-a-point-cloud-using-scene-depth). The sample documentation distinguishes its current single-frame version from its original accumulating version. [ExampleOfiOSLiDAR](https://github.com/TokyoYoshida/ExampleOfiOSLiDAR) was also inspected for sampling/rendering, but its point budget alone is not evidence of better measurement accuracy. No external code was copied.

The iteration preserves existing interface layout, sound rules, motion thresholds and obstacle selection. Only the display-cloud density/history and its existing count caption changed. Automated checks cover deduplication, expiration, reset, invalid data and capacity. Chair coverage and device frame rate still require an on-device A/B comparison.

### Quieter proximity audio

Far surfaces now produce soft, sparse clicks; close obstacles retain urgent pulses/continuous tone. No heartbeat was added: no active cells means silence when Camera far preview is off; when enabled, only a confirmed distant estimate can add a cue. Cell-selection changes no longer reset pulse timers, and distant sources share the current distance-based cooldown. This does not classify traversable floor versus obstacles: the current detector can still select ground or walls inside 3 m. If a reportedly empty scene continues to sound rapidly, inspect the highlighted cell distances before changing detection thresholds. Axis Test and motion-warning sounds are unchanged.


## Experimental camera far preview (3–10 m target range)

Uses [Depth Anything V2 Small](https://github.com/DepthAnything/Depth-Anything-V2)
through [Apple's Core ML F16 conversion](https://huggingface.co/apple/coreml-depth-anything-v2-small).
This estimates surfaces without assigning object names. It does **not** extend the
LiDAR hardware's measurement range or establish reliable 10 m obstacle detection.
The existing dense LiDAR display, motion alerts and near sound design are retained.
A separate **Camera far preview (experimental)** toggle defaults on and can be
switched off to compare with the baseline. The model is included in the Xcode
project and compiled into the app; first build/start may take longer.

Implementation:

- `CameraDepthInput.swift` rotates the sensor image clockwise to upright portrait,
  letterboxes it into 518 × 392 BGRA, and supplies the content rectangle. Samples
  map between portrait and original sensor coordinates using ARKit's full-image
  display transform. Padded pixels are not calibration or obstacle samples.
- `VisualDepthService.swift` accepts at most two frames/second and one inference
  in flight. It copies a small image and calibration samples before returning to
  ARKit, rather than retaining ARFrame on the worker queue. Model inference runs
  on a separate utility queue. Stop, instability and tracking loss invalidate
  generations; results older than 1.2 seconds cannot produce audio. The latest
  near-depth/pose stream must also remain fresh within 0.4 seconds.
- `VisualDepthCalibration.swift` fits `1 / meters = a * relativeDepth + b` to
  high-confidence 0.5–4 m LiDAR samples from the same frame. It requires at least
  100 valid pairs, 0.8 m depth spread, a positive slope, trimmed regression and
  held-out residual checks. A uniform-depth wall may not permit calibration.
  There is no fallback that treats raw model values as meters.
- Extrapolation is capped at 10 m and 2.5 times the calibration depth's 90th
  percentile. An inverse-depth residual gate further limits range. **These are
  heuristics, not calibrated confidence intervals or proof of far-range accuracy.**
  Good near-range fit does not guarantee correct far-range scale.
- Candidates must form a coherent small image patch and agree across consecutive
  inferences. The corridor is 1.3 m wide and spans 0.45 m below to 0.6 m above the
  camera in gravity-aligned world space. It requires an upright chest mount.
  This deliberately excludes much of the floor and side walls, but **can miss
  low chairs, curbs, hanging objects outside this band, thin obstacles, glass and
  distant obstacles hidden behind nearby objects**. There is no ground-plane or
  complete-path traversability classifier.
- A confirmed estimate gets a separate world-positioned 600 Hz, 180 ms soft beep (15 ms attack, 40 ms release):
  one-second intervals at 3.6 m and beyond, shortening to 0.9 seconds at 3 m, with gain
  0.04–0.08. The first eligible confirmed target triggers immediately; later
  pulses keep the cooldown across target changes. The far sound status line shows
  whether a cue is enabled or is yielding to near LiDAR audio. Any active near LiDAR obstacle takes priority and suppresses the
  far cue. Near LiDAR can still select floor/walls and thus suppress far audio.
  Axis Test temporarily takes priority over both. No confirmed estimate means
  no far tone; it never means the path is clear.
- The camera estimate appears separately as `≈ … m · experimental`; estimated
  points are not mixed into the measured LiDAR cloud or 5 × 2 debug grid.

### On-device acceptance check

1. Open this same `EchoSpace.xcodeproj`, select the connected LiDAR iPhone and
   press Cmd+R. If prompted, choose Replace. No Xcode restart is normally needed.
2. With AirPods connected, Start and verify Axis Test. Confirm the new far-preview
   switch is on. Aim into a well-lit textured scene that contains both nearby
   surfaces (0.5–4 m) for calibration and a larger distant obstruction.
3. Remain stationary with a sighted helper. Compare the camera estimate against
   measured distances at 3, 5, 8 and 10 m. Check detection misses, false cues,
   left/right alignment and whether estimates change smoothly. A status of
   waiting for calibration means far cues are disabled, not that the path is clear.
4. With no active orange near target, listen for the approximately one-second far
   interval. Then bring an obstacle within 3 m and confirm near sound takes over.
   Toggle far preview off/on to compare; toggle must not create an extra burst.
5. Test Start/Stop, tracking occlusion, motion warning, backgrounding and AirPods
   route changes. No old far cue should survive invalidation. Compare Xcode CPU,
   memory, temperature and camera responsiveness with preview off/on for 10 minutes.

Validated locally: unsigned iPhone Debug build, native calibration/degeneracy/
noise/range/staleness/temporal/corridor/priority checks and all baseline tests.
The bundled model completed a real Mac CPU inference with finite 518 × 392
Float16 output. A colored pixel-buffer test verifies portrait rotation and
letterbox sampling. These checks do not measure iPhone performance or real-world
obstacle accuracy; the device acceptance checks above remain outstanding.

Reproduce model/rotation smoke checks on macOS (requires normal Core ML access):

```sh
xcrun coremlcompiler compile EchoSpace/Models/DepthAnythingV2SmallF16.mlpackage /tmp/EchoSpace-model-check
xcrun swiftc -module-cache-path /tmp/EchoSpaceSwiftCache EchoSpace/CameraDepthInput.swift Tests/ModelSmoke/main.swift -o /tmp/EchoSpaceModelSmoke
/tmp/EchoSpaceModelSmoke /tmp/EchoSpace-model-check/DepthAnythingV2SmallF16.mlmodelc
```

Model provenance, checksums and Apache license are in `ThirdParty/`, also bundled
as app resources. `python3 Scripts/fetch_depth_model.py` restores model files from
the pinned revision and verifies their saved checksums before replacing files.
The pre-feature baseline is retained on `main`, tag `pre-stress-quiet-audio-v1`;
this iteration is on `feature/visual-depth-preview`.


### Current-mesh point and sound linkage

A current LiDAR triangle mesh now always supplies a measured soft-cue target,
including beyond the old 3 m active-grid cutoff. The nearest current triangle
vertex provides the world position. A 180 ms beep plays immediately when eligible, with intervals from 0.4 seconds
at 1 m to 1 second at 3.6 m and beyond, and gain 0.18–0.12.
The mesh cue replaces faint cell clicks in the 1–3 m band. Only an active obstacle
below 1 m takes over with the existing urgent cell tones. The mesh cue precedes
the experimental camera estimate. This linkage is independent of the Camera far preview toggle.
Only current triangles feed it: the 0.8-second point history never triggers sound.
Tracking loss, motion pause, Stop and stale data still silence directional cues.

Wireframe forces point rendering on and adds larger white vertex dots so lines
cannot appear without visible point marks. The Points switch reflects this and
is disabled while Wireframe is on. An orange sphere and meter label show the
measured mesh sound target even when a near target is active; the original grid
continues to highlight only its <=3 m cells. The sound status appears regardless
of the camera-preview toggle. Any measured mesh (including ground or walls) can
trigger this requested scan cue; it is not semantic obstacle classification.

Device check: aim at a surface 3–4 m away, turn Camera far preview off, and verify
white vertex dots, an orange target and a beep roughly every 1 second.
A 1–3 m grid cell must no longer suppress the mesh cue. Approach inside 1 m to
verify urgent near cues take priority. Cover the camera, Stop or
trigger a motion pause to verify that old mesh/point history cannot keep beeping.
Compilation and synthetic mesh-target checks do not verify AirPods loudness.


### MESH ALERT v4 · 1 s device identification

The camera overlay shows **MESH ALERT v4 · 1 s**, the measured LiDAR target distance,
and **Mesh beeps queued**. The counter increments only when a mesh beep is
scheduled for playback; it does not prove audible headphone output. The audio
route is displayed beside the sound status. If the counter advances but sound
is absent, compare Axis Test and the selected output/volume on the device.
White mesh dots and orange target spheres render above the debug geometry to
avoid depth-buffer occlusion; they are debug overlays, not occlusion-correct
physical reconstructions. Marker sizes increase with distance for legibility.

The regression test exercises the exact shared policy used by the audio engine:
a fresh mesh with an active 2.8 m cell still plays the mesh cue; <1 m urgency,
missing/old/future timestamps correctly suppress it. Device audibility still
requires a run of this newly built version on the iPhone.


### Unified faster rhythm (v4)

All three cue paths use `ProximityRhythm`: >=3.6 m: 1.0 s, 3 m: 0.9 s,
2 m: 0.65 s, 1 m: 0.4 s, 0.5 m: 0.1 s; below 0.5 m the existing
continuous near tone remains. Intervals interpolate between these distances.
A nearer active grid cell accelerates the mesh rhythm even if its own surface
has no connected triangle. The old three-second global cell lockout is removed;
cell churn still cannot reset cooldowns. Volume and detection thresholds are
unchanged. Freshness, tracking, motion and Axis Test priority remain enforced.
Endpoint, monotonicity and old-lockout regression checks pass locally; physical
AirPods timing and loudness remain device acceptance checks.
