import Foundation
import CoreML
import CoreImage
precondition(CommandLine.arguments.count == 2, "Pass compiled .mlmodelc path")
let config = MLModelConfiguration()
config.computeUnits = .cpuOnly
let model = try MLModel(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]), configuration: config)
var buffer: CVPixelBuffer?
precondition(CVPixelBufferCreate(kCFAllocatorDefault, 518, 392, kCVPixelFormatType_32BGRA, [kCVPixelBufferIOSurfacePropertiesKey: [:]] as CFDictionary, &buffer) == kCVReturnSuccess)
let context = CIContext(options: [.useSoftwareRenderer: true])
context.render(CIImage(color: CIColor(red: 0.5, green: 0.3, blue: 0.2)).cropped(to: CGRect(x: 0, y: 0, width: 518, height: 392)), to: buffer!)
let start = Date()
let result = try model.prediction(from: MLDictionaryFeatureProvider(dictionary: ["image": MLFeatureValue(pixelBuffer: buffer!)]))
let depth = result.featureValue(for: "depth")!.imageBufferValue!
precondition(CVPixelBufferGetWidth(depth) == 518 && CVPixelBufferGetHeight(depth) == 392)
precondition(CVPixelBufferGetPixelFormatType(depth) == kCVPixelFormatType_OneComponent16Half)
CVPixelBufferLockBaseAddress(depth, .readOnly)
let base = CVPixelBufferGetBaseAddress(depth)!
var finite = 0
for y in 0..<392 {
    let row = base.advanced(by: y * CVPixelBufferGetBytesPerRow(depth)).assumingMemoryBound(to: UInt16.self)
    for x in 0..<518 { if Float(Float16(bitPattern: row[x])).isFinite { finite += 1 } }
}
CVPixelBufferUnlockBaseAddress(depth, .readOnly)
precondition(finite == 518 * 392)
print("PASS: Core ML BGRA input -> 518x392 Float16 finite depth, CPU inference \(Date().timeIntervalSince(start)) seconds (Mac only, no accuracy claim)")

// Sensor top-left red, top-right green, bottom-left blue, bottom-right yellow.
// Rotating portrait clockwise must yield blue/red/yellow/green at TL/TR/BL/BR.
var sensor: CVPixelBuffer?
precondition(CVPixelBufferCreate(kCFAllocatorDefault, 400, 300, kCVPixelFormatType_32BGRA,
    [kCVPixelBufferIOSurfacePropertiesKey: [:]] as CFDictionary, &sensor) == kCVReturnSuccess)
CVPixelBufferLockBaseAddress(sensor!, [])
let sensorBase = CVPixelBufferGetBaseAddress(sensor!)!
for y in 0..<300 {
    let row = sensorBase.advanced(by: y * CVPixelBufferGetBytesPerRow(sensor!)).assumingMemoryBound(to: UInt8.self)
    for x in 0..<400 {
        let color: [UInt8] = y < 150 ? (x < 200 ? [0,0,255,255] : [0,255,0,255]) : (x < 200 ? [255,0,0,255] : [0,255,255,255])
        for c in 0..<4 { row[x * 4 + c] = color[c] }
    }
}
CVPixelBufferUnlockBaseAddress(sensor!, [])
let prepared = CameraDepthInput.prepare(sensor!, context: context)!
CVPixelBufferLockBaseAddress(prepared.image, .readOnly)
let preparedBase = CVPixelBufferGetBaseAddress(prepared.image)!
let checks: [(Double, Double, [UInt8])] = [(0.25,0.25,[255,0,0]), (0.75,0.25,[0,0,255]), (0.25,0.75,[0,255,255]), (0.75,0.75,[0,255,0])]
for (u, v, expected) in checks {
    let x = Int((prepared.content.minX + u * prepared.content.width) * 518)
    let y = Int((prepared.content.minY + v * prepared.content.height) * 392)
    let pixel = preparedBase.advanced(by: y * CVPixelBufferGetBytesPerRow(prepared.image) + x * 4).assumingMemoryBound(to: UInt8.self)
    for c in 0..<3 { precondition(abs(Int(pixel[c]) - Int(expected[c])) < 4, "Portrait model alignment failed") }
}
CVPixelBufferUnlockBaseAddress(prepared.image, .readOnly)
print("PASS: real pixel-buffer portrait rotation and letterbox coordinate alignment")
