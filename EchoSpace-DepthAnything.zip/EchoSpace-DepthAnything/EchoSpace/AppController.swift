import SwiftUI
import ARKit
import AVFoundation
import QuartzCore

@MainActor
final class AppController: ObservableObject {
    @Published var demoContinuityEnabled = true {
        didSet { audio.setDemoContinuity(demoContinuityEnabled) }
    }
    @Published private(set) var demoToneActive = false
    @Published private(set) var headStatus = "Not calibrated · Using phone direction"
    @Published private(set) var canCalibrateHead = false
    @Published private(set) var headCalibrated = false
    @Published private(set) var headTurnText = ""
    private let headphones = HeadphoneMotionMonitor()
    private var headAlignment = HeadPoseAlignment()
    private var latestHeadSample: HeadphonePoseSample?
    private var latestCameraPose: simd_float4x4?
    private var latestCameraTimestamp = -Double.infinity
    private var cameraAngularSpeed = Double.infinity
    private var cameraTrackingNormal = false
    @Published private(set) var isRunning = false
    @Published private(set) var isStarting = false
    @Published private(set) var model = ObstacleModel()
    @Published private(set) var status = "Connect AirPods, then tap Start"
    @Published private(set) var axisLabel: String?
    @Published private(set) var hasPose = false
    @Published private(set) var route = ""
    @Published private(set) var surface = SurfaceMesh.empty
    @Published private(set) var meshPulseCount = 0
    @Published private(set) var surfaceCue: FarObstacle?
    @Published private(set) var surfaceRevision = 0
    @Published var showHelpPrompt = false
    @Published var showHelpSheet = false
    @Published private(set) var isUnstable = false
    @Published private(set) var motionAvailable = true
    @Published private(set) var farSoundStatus = "Far sound: stopped"
    @Published private(set) var farStatus = "Camera far preview · experimental"
    @Published var farPreviewEnabled = true {
        didSet {
            visual.setEnabled(farPreviewEnabled && isRunning && hasPose)
            visualResumedAt = CACurrentMediaTime()
            audio.updateFar(nil)
            farStatus = farPreviewEnabled ? "Far preview: waiting for calibration" : "Far preview off"
        }
    }
    private let visual = VisualDepthService()
    private var hasFreshDepth = false
    private var lastFarResult = -Double.infinity
    private var visualResumedAt = Double.infinity
    @Published var showPoints = true
    @Published var showWireframe = true
    var cameraSession: ARSession { sampler.session }
    func setCameraViewport(_ size: CGSize) { sampler.setViewportSize(size) }
    private let motion = MotionMonitor()
    private var watchdog: Timer?
    private var runStartedAt = Double.infinity
    private var lastSnapshotTime = -Double.infinity
    private var lastAlertTime = -Double.infinity
    private let snapshotMailbox = LatestValueMailbox<DepthSnapshot>()
    private var lastSurfacePublish = -Double.infinity
    private var audioInterrupted = false
    private let sampler = DepthSampler()
    private let audio = SpatialAudioEngine()
    private var startingPose: simd_float4x4?
    private var observers: [NSObjectProtocol] = []
    private var generation = 0

    init() {
        headphones.onSample = { [weak self] sample in self?.receiveHeadphone(sample) }
        headphones.onUnavailable = { [weak self] message in
            guard let self else { return }
            self.latestHeadSample = nil
            self.resetHeadCalibration(message: message)
        }
        sampler.onCameraFrame = { [weak visual] frame, viewport in visual?.submit(frame, viewportSize: viewport) }
        visual.onResult = { [weak self] result in
            Task { @MainActor in
                guard let self, self.isRunning, self.farPreviewEnabled, self.hasPose, self.hasFreshDepth,
                      result.timestamp >= self.visualResumedAt, CACurrentMediaTime() - result.timestamp < 1.2 else { return }
                self.lastFarResult = result.timestamp
                self.farStatus = result.status
                self.audio.updateFar(result.candidate)
            }
        }
        let mailbox = snapshotMailbox
        sampler.onSnapshot = { [weak self] snapshot in
            guard mailbox.put(snapshot) else { return }
            Task { @MainActor in
                guard let snapshot = mailbox.take() else { return }
                self?.receive(snapshot)
            }
        }
        sampler.onFailure = { [weak self] message in
            Task { @MainActor in self?.stop(message: message) }
        }
        motion.onChange = { [weak self] unstable in self?.motionChanged(unstable) }
        motion.onUnavailable = { [weak self] in
            guard let self else { return }
            self.motionAvailable = false
            if self.isUnstable { self.motionChanged(false) }
        }
        audio.onDemoState = { [weak self] active in self?.demoToneActive = active }
        audio.onMeshPulse = { [weak self] in self?.meshPulseCount += 1 }
        audio.onFarStatus = { [weak self] status in self?.farSoundStatus = status }
        audio.onAxisLabel = { [weak self] label in self?.axisLabel = label }
        for name in [AVAudioSession.interruptionNotification, AVAudioSession.routeChangeNotification,
                     AVAudioSession.mediaServicesWereResetNotification, NSNotification.Name.AVAudioEngineConfigurationChange] {
            observers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] notification in
                Task { @MainActor in self?.handleAudioNotification(notification) }
            })
        }
    }

    private func handleAudioNotification(_ notification: Notification) {
        guard isRunning else { return }
        if notification.name == AVAudioSession.mediaServicesWereResetNotification {
            stop(message: "System audio service restarted. Tap Start to restart EchoSpace.")
            return
        }
        if notification.name == AVAudioSession.interruptionNotification {
            guard let raw = notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
            if type == .began {
                audioInterrupted = true
                audio.suspendForSystemInterruption()
                status = "System audio interruption · Scanning continues"
                return
            }
            audioInterrupted = false
            let rawOptions = notification.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            guard AVAudioSession.InterruptionOptions(rawValue: rawOptions).contains(.shouldResume) else {
                stop(message: "System audio requires a new start. Tap Start to resume.")
                return
            }
        }
        // Category/override/route configuration notifications are common around
        // recording. A notification by itself must not stop the AR session.
        route = AVAudioSession.sharedInstance().currentRoute.outputs.map(\.portName).joined(separator: ", ")
        if notification.name == AVAudioSession.routeChangeNotification,
           let raw = notification.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
           let reason = AVAudioSession.RouteChangeReason(rawValue: raw),
           reason == .oldDeviceUnavailable || reason == .newDeviceAvailable {
            resetHeadCalibration(message: "Audio device changed · Recalibrate headphones if needed")
        }
        guard !audioInterrupted else { return }
        do { try audio.resumeIfNeeded() }
        catch { stop(message: "Audio could not recover. Tap Start to retry: \(error.localizedDescription)") }
    }

    func start() async {
        guard !isRunning, !isStarting else { return }
        guard ARWorldTrackingConfiguration.supportsFrameSemantics(.smoothedSceneDepth) else {
            status = "Requires a LiDAR iPhone Pro. Simulator depth is unavailable."
            return
        }
        isStarting = true
        generation += 1
        let request = generation
        let permitted = await AVCaptureDevice.requestAccess(for: .video)
        guard request == generation else { return }
        isStarting = false
        guard permitted else { status = "Allow Camera in Settings → EchoSpace to use LiDAR."; return }
        do {
            meshPulseCount = 0; audioInterrupted = false; lastSurfacePublish = -.infinity
            try audio.start()
            audio.setDemoContinuity(demoContinuityEnabled)
            startingPose = nil; hasPose = false
            model.update(ObstacleCell.emptyGrid)
            isRunning = true
            UIApplication.shared.isIdleTimerDisabled = true
            status = "Starting LiDAR — hold the phone upright"
            route = AVAudioSession.sharedInstance().currentRoute.outputs.map(\.portName).joined(separator: ", ")
            runStartedAt = CACurrentMediaTime()
            lastSnapshotTime = runStartedAt
            isUnstable = false; motionAvailable = true
            resetHeadCalibration(message: "Wear your headphones and face forward with the camera, then calibrate")
            latestCameraPose = nil; latestCameraTimestamp = -.infinity
            cameraAngularSpeed = .infinity; cameraTrackingNormal = false
            headphones.start()
            motion.start()
            sampler.start()
            watchdog = Timer(timeInterval: 0.1, repeats: true) { [weak self] _ in
                MainActor.assumeIsolated {
                    guard let self, self.isRunning else { return }
                    self.updateCalibrationAvailability()
                    if self.farPreviewEnabled && CACurrentMediaTime() - self.lastFarResult >= 1.2 {
                        self.audio.updateFar(nil)
                        self.farStatus = "Far preview: waiting for fresh calibrated depth"
                    }
                    guard CACurrentMediaTime() - self.lastSnapshotTime > 0.4 else { return }
                    self.clearExpiredMeasurements()
                    self.status = self.demoContinuityEnabled ? "Demo audio active · Refreshing depth" : "Scanning — waiting for fresh depth"
                }
            }
            if let watchdog { RunLoop.main.add(watchdog, forMode: .common) }
        } catch { stop(message: "Audio could not start: \(error.localizedDescription)") }
    }

    func stop(message: String = "Stopped") {
        generation += 1; isStarting = false; isRunning = false
        watchdog?.invalidate(); watchdog = nil
        headphones.stop(); latestHeadSample = nil
        resetHeadCalibration(message: "Stopped · Calibrate again after Start")
        latestCameraPose = nil; latestCameraTimestamp = -.infinity
        motion.stop(); isUnstable = false; showHelpPrompt = false
        visual.setEnabled(false); visualResumedAt = .infinity
        farStatus = "Camera far preview · experimental"
        hasFreshDepth = false
        sampler.stop(); audio.stop()
        surfaceCue = nil; audio.updateSurface(nil)
        surface = .empty; surfaceRevision += 1
        model.update(ObstacleCell.emptyGrid)
        startingPose = nil; hasPose = false; status = message
        UIApplication.shared.isIdleTimerDisabled = false
    }

    func axisTest() {
        guard isRunning, hasPose, let startingPose else { return }
        audio.axisTest(startingPose: startingPose)
    }

    /// Expire measurements without disabling AR, model inference or the audio engine.
    /// A new frame can supply cues immediately, even while the phone is shaking.
    private func clearExpiredMeasurements() {
        hasFreshDepth = false
        if axisLabel != nil { audio.cancelAxisTest() }
        audio.updateFar(nil)
        model.update(ObstacleCell.emptyGrid)
        surfaceCue = nil; audio.updateSurface(nil)
        if !surface.vertices.isEmpty || !surface.pointCloud.isEmpty {
            surface = .empty; surfaceRevision += 1
        }
        lastSurfacePublish = -.infinity
        audio.update(cells: [], cameraPose: audio.currentCameraPose(), valid: true)
    }

    private func motionChanged(_ unstable: Bool) {
        guard isRunning else { return }
        isUnstable = unstable
        // Clear cloud history to avoid motion trails; keep current measurements
        // and sound updates running rather than introducing a pause state.
        sampler.setSurfaceAccumulationEnabled(!unstable)
        if unstable {
            let now = CACurrentMediaTime()
            if now - lastAlertTime > 3 {
                lastAlertTime = now
                UINotificationFeedbackGenerator().notificationOccurred(.warning)
                audio.playMotionAlert()
                UIAccessibility.post(notification: .announcement, argument: "Movement detected. Do you need help? Scanning continues.")
                if !showHelpSheet { showHelpPrompt = true }
            }
        }
    }

    func requestHelp() {
        showHelpPrompt = false
        showHelpSheet = true
    }

    private func updateCalibrationAvailability() {
        let now = CACurrentMediaTime()
        let outputIsHeadphones = AVAudioSession.sharedInstance().currentRoute.outputs.contains {
            [.bluetoothA2DP, .bluetoothHFP, .bluetoothLE].contains($0.portType)
        }
        canCalibrateHead = isRunning && outputIsHeadphones && cameraTrackingNormal && hasFreshDepth &&
            now - latestCameraTimestamp < 0.25 && cameraAngularSpeed < 0.35 &&
            (latestHeadSample.map { $0.isFresh(at: now) && $0.angularSpeed < 0.35 &&
                abs($0.timestamp - latestCameraTimestamp) < 0.15 } ?? false)
        if let sample = latestHeadSample, !sample.isFresh(at: now), headCalibrated {
            resetHeadCalibration(message: "Headphone data lost · Using phone direction. Please recalibrate")
        }
    }

    func calibrateHeadphones() {
        updateCalibrationAvailability()
        guard canCalibrateHead, let camera = latestCameraPose, let sample = latestHeadSample else {
            headStatus = "Connect headphones and hold your head and phone steady. Wait for fresh data, then calibrate"
            return
        }
        guard headAlignment.calibrate(camera: camera, headphone: sample.orientation) else {
            headStatus = "Hold the phone upright, facing forward, and try again"; return
        }
        headCalibrated = true
        applyHeadphoneSample(sample)
        UIAccessibility.post(notification: .announcement, argument: "Calibration complete. Sound now follows your head direction.")
    }

    func resetHeadCalibration(message: String = "Using phone direction · Recalibrate whenever you are ready") {
        headAlignment.reset(); headCalibrated = false; canCalibrateHead = false
        headTurnText = ""; headStatus = message
        audio.updateHeadOrientation(nil)
    }

    private func receiveHeadphone(_ sample: HeadphonePoseSample) {
        guard isRunning else { return }
        latestHeadSample = sample
        updateCalibrationAvailability()
        if headCalibrated { applyHeadphoneSample(sample) }
        else { headStatus = "Headphone motion connected · Face forward with the camera, then calibrate" }
    }

    private func applyHeadphoneSample(_ sample: HeadphonePoseSample) {
        guard sample.isFresh(at: CACurrentMediaTime()), let orientation = headAlignment.orientation(headphone: sample.orientation) else {
            resetHeadCalibration(message: "Head direction unavailable · Using phone direction. Please recalibrate"); return
        }
        // Only listener orientation changes. The camera's detection zones and all
        // obstacle world positions remain untouched.
        audio.updateHeadOrientation(orientation)
        headStatus = "Calibrated · Sound follows left and right head turns"
        if let camera = latestCameraPose {
            let forward = orientation.act(SIMD3<Float>(0,0,-1))
            let cameraForward = -SIMD3(camera[2].x, camera[2].y, camera[2].z)
            let cameraRight = SIMD3(camera[0].x, camera[0].y, camera[0].z)
            let angle = atan2(simd_dot(forward, cameraRight), simd_dot(forward, cameraForward)) * 180 / .pi
            headTurnText = String(format: "Head relative to camera: %+.0f° (+right / −left)", angle)
        }
    }

    private func receive(_ snapshot: DepthSnapshot) {
        guard isRunning, snapshot.timestamp >= runStartedAt else { return }
        lastSnapshotTime = CACurrentMediaTime()
        guard snapshot.hasDepthMeasurements, lastSnapshotTime - snapshot.timestamp < 0.4 else {
            clearExpiredMeasurements()
            status = demoContinuityEnabled ? "Demo audio active · Refreshing depth" : (snapshot.hasDepthMeasurements ? "Scanning — waiting for fresh depth" : snapshot.message)
            return
        }
        hasFreshDepth = true
        if let previous = latestCameraPose, snapshot.timestamp > latestCameraTimestamp {
            let a = simd_quatf(previous), b = simd_quatf(snapshot.listenerTransform)
            let dot = min(1, abs(simd_dot(a.vector, b.vector)))
            cameraAngularSpeed = Double(2 * acos(dot)) / (snapshot.timestamp - latestCameraTimestamp)
        }
        latestCameraPose = snapshot.listenerTransform
        latestCameraTimestamp = snapshot.timestamp
        cameraTrackingNormal = snapshot.trackingIsNormal
        updateCalibrationAvailability()
        // Audio/depth still update at 15 Hz; redraw expensive cloud geometry at 10 Hz.
        if snapshot.timestamp - lastSurfacePublish >= 0.1 {
            surface = snapshot.surface; surfaceRevision += 1
            lastSurfacePublish = snapshot.timestamp
        }
        model.update(snapshot.cells, warningSamples: snapshot.warningCells)
        let origin = SpatialGeometry.position(snapshot.listenerTransform)
        surfaceCue = snapshot.centerSurfacePoint.map {
            FarObstacle(worldPosition: $0, distance: simd_distance($0, origin), timestamp: snapshot.timestamp)
        }
        audio.updateSurface(surfaceCue)
        if !hasPose { visualResumedAt = snapshot.timestamp }
        hasPose = true
        visual.setEnabled(farPreviewEnabled)
        if startingPose == nil && snapshot.trackingIsNormal { startingPose = snapshot.listenerTransform }
        status = snapshot.message
        audio.update(cells: model.cells, cameraPose: snapshot.listenerTransform, valid: true)
    }
}
