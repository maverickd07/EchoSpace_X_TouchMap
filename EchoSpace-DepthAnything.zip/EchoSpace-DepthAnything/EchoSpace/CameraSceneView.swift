import SwiftUI
import ARKit
import SceneKit

/// ARSCNView renders the same ARSession camera used by the depth sampler.
/// Geometry is already in world coordinates: no image-to-screen pan shortcuts.
struct CameraSceneView: UIViewRepresentable {
    let session: ARSession
    let surface: SurfaceMesh
    let cells: [ObstacleCell]
    let surfaceCue: FarObstacle?
    let showPoints: Bool
    let showWireframe: Bool
    let visible: Bool
    let revision: Int
    var onViewportChange: (CGSize) -> Void

    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> ARSCNView {
        let view = PreviewView(frame: .zero)
        view.onViewportChange = onViewportChange
        view.session = session
        view.scene = SCNScene()
        view.preferredFramesPerSecond = 30
        view.automaticallyUpdatesLighting = false
        view.autoenablesDefaultLighting = false
        view.scene.rootNode.addChildNode(context.coordinator.surfaceRoot)
        view.scene.rootNode.addChildNode(context.coordinator.markerRoot)
        view.accessibilityElementsHidden = true
        return view
    }

    func updateUIView(_ view: ARSCNView, context: Context) {
        let coordinator = context.coordinator
        coordinator.surfaceRoot.isHidden = !visible
        coordinator.markerRoot.isHidden = !visible
        guard visible else { return }
        guard coordinator.revision != revision || coordinator.points != showPoints || coordinator.wire != showWireframe else { return }
        coordinator.revision = revision; coordinator.points = showPoints; coordinator.wire = showWireframe
        coordinator.surfaceRoot.childNodes.forEach { $0.removeFromParentNode() }
        coordinator.markerRoot.childNodes.forEach { $0.removeFromParentNode() }
        let vertices = surface.vertices.map { SCNVector3($0.x, $0.y, $0.z) }
        if !vertices.isEmpty {
            let source = SCNGeometrySource(vertices: vertices)
            if showWireframe && !surface.triangles.isEmpty {
                let element = SCNGeometryElement(indices: surface.triangles, primitiveType: .triangles)
                let geometry = SCNGeometry(sources: [source], elements: [element])
                let material = Coordinator.material(.cyan.withAlphaComponent(0.45))
                material.fillMode = .lines
                geometry.materials = [material]
                coordinator.surfaceRoot.addChildNode(SCNNode(geometry: geometry))
            }
        }
        if (showPoints || showWireframe) && !surface.pointCloud.isEmpty {
            // One batched geometry, not one SceneKit node per point.
            let cloudSource = SCNGeometrySource(vertices: surface.pointCloud.map { SCNVector3($0.x, $0.y, $0.z) })
            let element = SCNGeometryElement(indices: (0..<surface.pointCloud.count).map { Int32($0) }, primitiveType: .point)
            element.pointSize = 2
            element.minimumPointScreenSpaceRadius = 0.8
            element.maximumPointScreenSpaceRadius = 1.6
            let geometry = SCNGeometry(sources: [cloudSource], elements: [element])
            geometry.materials = [Coordinator.material(.cyan.withAlphaComponent(0.8))]
            coordinator.surfaceRoot.addChildNode(SCNNode(geometry: geometry))
        }
        // Larger bright dots at every wireframe vertex remain visible even when
        // the dense cyan cloud blends into the cyan lines at a distance.
        if showWireframe && !surface.triangles.isEmpty {
            let indices = Array(Set(surface.triangles)).sorted()
            let geometry = SCNGeometry(sources: [SCNGeometrySource(vertices: vertices)],
                                      elements: [SCNGeometryElement(indices: indices, primitiveType: .point)])
            geometry.elements[0].pointSize = 5
            geometry.elements[0].minimumPointScreenSpaceRadius = 2
            geometry.elements[0].maximumPointScreenSpaceRadius = 3
            let dots = Coordinator.material(.white)
            dots.readsFromDepthBuffer = false
            dots.writesToDepthBuffer = false
            geometry.materials = [dots]
            let dotNode = SCNNode(geometry: geometry)
            dotNode.renderingOrder = 10
            coordinator.surfaceRoot.addChildNode(dotNode)
        }
        var markers = cells
        if let cue = surfaceCue {
            markers.append(ObstacleCell(id: 10, worldPosition: cue.worldPosition, distance: cue.distance, isActive: true))
        }
        for cell in markers where cell.isActive {
            guard let p = cell.worldPosition, let distance = cell.distance else { continue }
            let marker = SCNNode()
            marker.simdPosition = p
            // Keep the marker legible in screen space as the surface gets farther away.
            let sphere = SCNSphere(radius: CGFloat(max(0.025, min(0.09, distance * 0.012))))
            sphere.segmentCount = 12
            sphere.materials = [Coordinator.material(distance < 0.5 ? .systemRed : .systemOrange)]
            sphere.materials[0].readsFromDepthBuffer = false
            sphere.materials[0].writesToDepthBuffer = false
            let dot = SCNNode(geometry: sphere)
            dot.renderingOrder = 20
            marker.addChildNode(dot)
            let text = SCNText(string: String(format: "%.2f m", distance), extrusionDepth: 0)
            text.font = .monospacedSystemFont(ofSize: 12, weight: .bold)
            text.flatness = 1
            text.materials = [Coordinator.material(.white)]
            let label = SCNNode(geometry: text)
            label.scale = SCNVector3(0.004, 0.004, 0.004)
            label.position = SCNVector3(0.045, 0.04, 0)
            label.constraints = [SCNBillboardConstraint()]
            marker.addChildNode(label)
            coordinator.markerRoot.addChildNode(marker)
        }
    }

    final class PreviewView: ARSCNView {
        var onViewportChange: ((CGSize) -> Void)?
        private var previousSize = CGSize.zero
        override func layoutSubviews() {
            super.layoutSubviews()
            guard bounds.size != previousSize, bounds.width > 0, bounds.height > 0 else { return }
            previousSize = bounds.size
            onViewportChange?(bounds.size)
        }
    }

    final class Coordinator {
        let surfaceRoot = SCNNode()
        let markerRoot = SCNNode()
        var revision = -1
        var points = false
        var wire = true
        static func material(_ color: UIColor) -> SCNMaterial {
            let material = SCNMaterial()
            material.lightingModel = .constant
            material.diffuse.contents = color
            material.isDoubleSided = true
            return material
        }
    }
}
