import Foundation
import simd

struct DepthPair {
    let relative: Float
    let meters: Float
}

/// Fits inverse metric depth, never interprets relative model values as meters.
struct VisualDepthCalibration {
    let slope: Float
    let intercept: Float
    let inverseError: Float
    let maximumRange: Float

    static func fit(_ input: [DepthPair]) -> Self? {
        let pairs = input.filter { $0.relative.isFinite && $0.meters.isFinite && $0.meters >= 0.5 && $0.meters <= 4 }
        guard pairs.count >= 100 else { return nil }
        let depths = pairs.map(\.meters).sorted()
        guard depths[depths.count * 9 / 10] - depths[depths.count / 10] >= 0.8 else { return nil }
        let train = pairs.enumerated().filter { $0.offset % 5 != 0 }.map(\.element)
        let heldOut = pairs.enumerated().filter { $0.offset % 5 == 0 }.map(\.element)
        func regress(_ points: [DepthPair]) -> (Float, Float)? {
            let n = Float(points.count)
            let x = points.reduce(Float(0)) { $0 + $1.relative } / n
            let y = points.reduce(Float(0)) { $0 + 1 / $1.meters } / n
            let variance = points.reduce(Float(0)) { $0 + pow($1.relative - x, 2) }
            guard variance > 0.00001 else { return nil }
            let a = points.reduce(Float(0)) { $0 + ($1.relative - x) * (1 / $1.meters - y) } / variance
            let b = y - a * x
            return a.isFinite && b.isFinite && a > 0 ? (a, b) : nil
        }
        guard let first = regress(train) else { return nil }
        let trimmed = train.sorted {
            abs(first.0 * $0.relative + first.1 - 1 / $0.meters) < abs(first.0 * $1.relative + first.1 - 1 / $1.meters)
        }
        guard let (a, b) = regress(Array(trimmed.prefix(train.count * 4 / 5))) else { return nil }
        var relativeErrors: [Float] = [], inverseErrors: [Float] = []
        for pair in heldOut {
            let inverse = a * pair.relative + b
            guard inverse > 0 else { return nil }
            relativeErrors.append(abs(1 / inverse - pair.meters) / pair.meters)
            inverseErrors.append(abs(inverse - 1 / pair.meters))
        }
        relativeErrors.sort(); inverseErrors.sort()
        guard relativeErrors[relativeErrors.count / 2] < 0.12,
              relativeErrors[relativeErrors.count * 9 / 10] < 0.25 else { return nil }
        return Self(slope: a, intercept: b,
                    inverseError: max(0.004, inverseErrors[inverseErrors.count * 9 / 10]),
                    maximumRange: min(10, depths[depths.count * 9 / 10] * 2.5))
    }

    func meters(relative: Float) -> Float? {
        let inverse = slope * relative + intercept
        guard inverse.isFinite, inverse > 0, inverseError / inverse <= 0.2 else { return nil }
        let distance = 1 / inverse
        return distance > 3 && distance <= maximumRange ? distance : nil
    }
}

struct FarObstacle {
    let worldPosition: SIMD3<Float>
    let distance: Float
    let timestamp: Double
}

struct FarObstacleConfirmation {
    private var previous: FarObstacle?
    mutating func reset() { previous = nil }
    mutating func update(_ candidate: FarObstacle?) -> FarObstacle? {
        defer { previous = candidate }
        guard let candidate, let previous,
              candidate.timestamp > previous.timestamp,
              candidate.timestamp - previous.timestamp < 1.3,
              simd_distance(candidate.worldPosition, previous.worldPosition) < 1,
              abs(candidate.distance - previous.distance) < 1 else { return nil }
        return candidate
    }
}

enum FarCuePolicy {
    static func interval(distance: Float) -> Double { ProximityRhythm.interval(distance: distance) }
    static func gain(distance: Float) -> Float { 0.04 + (10 - min(10, max(3, distance))) * 0.04 / 7 }
    static func allowed(_ candidate: FarObstacle, now: Double, hasNearObstacle: Bool) -> Bool {
        !hasNearObstacle && candidate.distance > 3 && candidate.distance <= 10 &&
        now >= candidate.timestamp && now - candidate.timestamp < 1.2
    }
    /// Narrow chest-height corridor. Floor and side walls are not forward obstacles here.
    static func inCorridor(_ offset: SIMD3<Float>, right: SIMD3<Float>, forward: SIMD3<Float>) -> Bool {
        let ahead = simd_dot(offset, forward)
        return ahead > 3 && ahead <= 10 && abs(simd_dot(offset, right)) < 0.65 && offset.y > -0.45 && offset.y < 0.6
    }
}
