import CoreImage

/// Portrait, aspect-preserving letterbox. Both calibration and prediction use
/// the same normalized top-left content rect; padded pixels are never sampled.
enum CameraDepthInput {
    static let width = 518, height = 392
    static func prepare(_ source: CVPixelBuffer, context: CIContext) -> (image: CVPixelBuffer, content: CGRect)? {
        var buffer: CVPixelBuffer?
        guard CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
                                 [kCVPixelBufferIOSurfacePropertiesKey: [:]] as CFDictionary, &buffer) == kCVReturnSuccess,
              let buffer else { return nil }
        let image = CIImage(cvPixelBuffer: source).oriented(.right)
        let scale = min(CGFloat(width) / image.extent.width, CGFloat(height) / image.extent.height)
        let w = image.extent.width * scale, h = image.extent.height * scale
        let left = (CGFloat(width) - w) / 2, bottom = (CGFloat(height) - h) / 2
        let resized = image.transformed(by: CGAffineTransform(translationX: -image.extent.minX, y: -image.extent.minY))
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            .transformed(by: CGAffineTransform(translationX: left, y: bottom))
        let bounds = CGRect(x: 0, y: 0, width: width, height: height)
        context.render(resized.composited(over: CIImage(color: .black).cropped(to: bounds)),
                       to: buffer, bounds: bounds, colorSpace: CGColorSpaceCreateDeviceRGB())
        return (buffer, CGRect(x: left / CGFloat(width), y: bottom / CGFloat(height),
                               width: w / CGFloat(width), height: h / CGFloat(height)))
    }
}
