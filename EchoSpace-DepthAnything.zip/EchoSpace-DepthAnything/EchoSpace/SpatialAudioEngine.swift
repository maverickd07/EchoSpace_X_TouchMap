import AVFoundation
import QuartzCore
import simd

@MainActor
final class SpatialAudioEngine {
    private let engine = AVAudioEngine()
    private let environment = AVAudioEnvironmentNode()
    private let players = (0..<10).map { _ in AVAudioPlayerNode() }
    private let demoPlayer = AVAudioPlayerNode()
    private let demoTone = SoundDesign.farWarningTone(frequency: 400)
    private var demoEnabled = false
    private var demoCadence = DemoContinuityCadence()
    private var demoIsSounding = false
    var onDemoState: ((Bool) -> Void)?
    private let alertPlayer = AVAudioPlayerNode()
    private let farPlayer = AVAudioPlayerNode()
    private var surfaceObstacle: FarObstacle?
    private var lastSurfacePulse = -Double.infinity
    private var farObstacle: FarObstacle?
    private var lastFarPulse = -Double.infinity
    private let farClick = SoundDesign.farWarningTone()
    private let testPlayer = AVAudioPlayerNode()
    private var systemInterrupted = false
    private var timer: Timer?
    private var cells: [ObstacleCell] = []
    private var headOrientation: simd_quatf?
    private var pose = matrix_identity_float4x4
    private var lastUpdate = -Double.infinity
    private var cadence = ObstaclePulseCadence()
    private var looping = [Bool](repeating: false, count: 10)
    private var sounding = [Bool](repeating: false, count: 10)
    private let clicks = [SoundDesign.tone(frequency: 1200, duration: 0.045, click: true),
                          SoundDesign.tone(frequency: 300, duration: 0.045, click: true)]
    private let continuous = [SoundDesign.tone(frequency: 1200, duration: 0.1, click: false),
                              SoundDesign.tone(frequency: 300, duration: 0.1, click: false)]
    private let axisTone = SoundDesign.tone(frequency: 700, duration: 0.1, click: false)
    private var testPositions: [SIMD3<Float>] = []
    private var testStart: Double?
    private var testStage = -1
    var onMeshPulse: (() -> Void)?
    var onFarStatus: ((String) -> Void)?
    private var farStatus = ""
    private func reportFarStatus(_ status: String) {
        guard farStatus != status else { return }
        farStatus = status; onFarStatus?(status)
    }
    var onAxisLabel: ((String?) -> Void)?

    init() {
        engine.attach(demoPlayer)
        engine.connect(demoPlayer, to: engine.mainMixerNode, format: SoundDesign.format)
        engine.attach(alertPlayer)
        engine.connect(alertPlayer, to: engine.mainMixerNode, format: SoundDesign.format)
        engine.attach(environment)
        // Explicit stereo output allows binaural HRTF rendering over AirPods/A2DP.
        engine.connect(environment, to: engine.mainMixerNode,
                       format: AVAudioFormat(standardFormatWithSampleRate: SoundDesign.sampleRate, channels: 2))
        for player in players + [testPlayer, farPlayer] {
            engine.attach(player)
            engine.connect(player, to: environment, format: SoundDesign.format)
            player.renderingAlgorithm = .HRTFHQ
            player.sourceMode = .pointSource
            player.reverbBlend = 0
        }
        environment.reverbParameters.enable = false
        // Explicit modest gain is the distance cue; avoid a second large attenuation.
        environment.distanceAttenuationParameters.rolloffFactor = 0
        engine.mainMixerNode.outputVolume = 0.8
    }

    /// The sole listener provider: calibrated head heading with camera position,
    /// or the original camera pose when head tracking is not calibrated/available.
    func listenerPose() -> simd_float4x4 {
        HeadPoseAlignment.listener(camera: pose, headOrientation: headOrientation)
    }
    func currentCameraPose() -> simd_float4x4 { pose }
    func updateHeadOrientation(_ orientation: simd_quatf?) {
        headOrientation = orientation
        applyListenerPose()
    }

    func setDemoContinuity(_ enabled: Bool) {
        demoEnabled = enabled
        if !enabled { demoPlayer.stop(); reportDemo(false) }
    }

    private func reportDemo(_ active: Bool) {
        guard demoIsSounding != active else { return }
        demoIsSounding = active; onDemoState?(active)
    }

    private func noteRealSound(at now: Double) {
        demoCadence.noteOutput(at: now)
        if demoIsSounding { demoPlayer.stop(); reportDemo(false) }
    }

    private func fillDemoGap(at now: Double) {
        guard demoCadence.shouldPulse(enabled: demoEnabled, now: now) else { return }
        demoPlayer.volume = 0.12
        demoPlayer.scheduleBuffer(demoTone)
        if !demoPlayer.isPlaying { demoPlayer.play() }
        reportDemo(true)
    }

    func suspendForSystemInterruption() {
        systemInterrupted = true
        demoPlayer.stop(); reportDemo(false)
        alertPlayer.stop(); silenceObstacles(); cancelAxisTest()
        engine.pause()
    }

    func resumeIfNeeded() throws {
        guard timer != nil else { return }
        if engine.isRunning && !systemInterrupted { return }
        demoPlayer.stop(); reportDemo(false)
        alertPlayer.stop(); silenceObstacles(); cancelAxisTest()
        try AVAudioSession.sharedInstance().setActive(true)
        engine.prepare()
        try engine.start()
        systemInterrupted = false
    }

    func start() throws {
        systemInterrupted = false
        demoCadence = DemoContinuityCadence()
        demoCadence.noteOutput(at: CACurrentMediaTime())
        headOrientation = nil
        cadence = ObstaclePulseCadence()
        surfaceObstacle = nil; lastSurfacePulse = -.infinity
        farObstacle = nil; lastFarPulse = -.infinity
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .default, options: [])
        try session.setPreferredSampleRate(SoundDesign.sampleRate)
        try session.setPreferredIOBufferDuration(0.01)
        try session.setActive(true)
        engine.prepare()
        try engine.start()
        timer = Timer(timeInterval: 0.01, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.tick() }
        }
        if let timer { RunLoop.main.add(timer, forMode: .common) }
    }

    func update(cells: [ObstacleCell], cameraPose: simd_float4x4, valid: Bool) {
        pose = cameraPose
        self.cells = valid ? cells : []
        lastUpdate = valid ? CACurrentMediaTime() : -.infinity
        applyListenerPose()
        if !valid { silenceObstacles(); cancelAxisTest() }
    }

    func updateSurface(_ obstacle: FarObstacle?) {
        if surfaceObstacle != nil && obstacle == nil { farPlayer.stop() }
        surfaceObstacle = obstacle
    }

    func updateFar(_ obstacle: FarObstacle?) {
        farObstacle = obstacle
        if obstacle == nil && surfaceObstacle == nil { farPlayer.stop(); reportFarStatus("Far sound: waiting for a confirmed target") }
    }

    private func applyListenerPose() {
        let transform = listenerPose()
        environment.listenerPosition = point(SpatialGeometry.position(transform))
        // Vectors, never Euler angles. -Z forward, +Y up in the listener camera pose.
        let forward = -SIMD3(transform[2].x, transform[2].y, transform[2].z)
        let up = SIMD3(transform[1].x, transform[1].y, transform[1].z)
        environment.listenerVectorOrientation = AVAudio3DVectorOrientation(
            forward: AVAudio3DVector(x: forward.x, y: forward.y, z: forward.z),
            up: AVAudio3DVector(x: up.x, y: up.y, z: up.z))
    }

    func axisTest(startingPose: simd_float4x4) {
        silenceObstacles()
        let origin = SpatialGeometry.position(startingPose)
        let right = simd_normalize(SIMD3(startingPose[0].x, startingPose[0].y, startingPose[0].z))
        let forward = -simd_normalize(SIMD3(startingPose[2].x, startingPose[2].y, startingPose[2].z))
        // Anchor once in WORLD space. Never move these positions with later frames.
        testPositions = [origin - right, origin + right, origin + forward]
        testStart = CACurrentMediaTime()
        testStage = -1
        tick()
    }

    func cancelAxisTest() {
        testPlayer.stop()
        testStart = nil
        testStage = -1
        onAxisLabel?(nil)
    }

    func playMotionAlert() {
        guard engine.isRunning else { return }
        noteRealSound(at: CACurrentMediaTime())
        alertPlayer.stop()
        alertPlayer.volume = 0.35
        alertPlayer.scheduleBuffer(SoundDesign.tone(frequency: 900, duration: 0.08, click: true))
        alertPlayer.scheduleBuffer(SoundDesign.tone(frequency: 650, duration: 0.08, click: true))
        alertPlayer.play()
    }

    func stop() {
        demoPlayer.stop(); reportDemo(false)
        alertPlayer.stop()
        timer?.invalidate(); timer = nil
        silenceObstacles(); cancelAxisTest()
        engine.stop()
        headOrientation = nil
        surfaceObstacle = nil
        farObstacle = nil
        reportFarStatus("Far sound: stopped")
        cells = []; lastUpdate = -.infinity
        cadence = ObstaclePulseCadence()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func tick() {
        guard engine.isRunning, !systemInterrupted else { return }
        let now = CACurrentMediaTime()
        guard now - lastUpdate < 0.4 else {
            silenceObstacles()
            reportFarStatus("Scanning — no fresh sound target")
            if testStart != nil { cancelAxisTest() }
            fillDemoGap(at: now)
            return
        }
        if let start = testStart {
            noteRealSound(at: now)
            reportFarStatus("Axis Test playing")
            let stage = Int((now - start) / 2)
            if stage >= 3 { cancelAxisTest(); return }
            if stage != testStage {
                testStage = stage
                testPlayer.stop()
                testPlayer.position = point(testPositions[stage])
                testPlayer.volume = 0.3
                testPlayer.scheduleBuffer(axisTone, at: nil, options: .loops)
                testPlayer.play()
                onAxisLabel?(["LEFT", "RIGHT", "AHEAD"][stage])
            }
            return
        }
        let nearestActive = cells.filter(\.isActive).compactMap(\.distance).min()
        let useMesh = MeshCuePolicy.usesMesh(timestamp: surfaceObstacle?.timestamp, now: now,
                                             nearestActiveDistance: nearestActive)
        if useMesh, let measured = surfaceObstacle {
            let interval = MeshCuePolicy.interval(distance: min(measured.distance, nearestActive ?? measured.distance))
            reportFarStatus(String(format: "LiDAR mesh cue: %.1f m · beep every %.1f s", measured.distance, interval))
            if now - lastSurfacePulse >= interval {
                farPlayer.position = point(measured.worldPosition)
                farPlayer.volume = MeshCuePolicy.gain(distance: measured.distance)
                noteRealSound(at: now)
                farPlayer.scheduleBuffer(farClick)
                if !farPlayer.isPlaying { farPlayer.play() }
                lastSurfacePulse = now
                onMeshPulse?()
            }
        } else if let far = farObstacle, FarCuePolicy.allowed(far, now: now, hasNearObstacle: cells.contains(where: \.isActive)) {
            reportFarStatus(String(format: "Far sound: soft beep every %.1f s", FarCuePolicy.interval(distance: far.distance)))
            if now - lastFarPulse >= FarCuePolicy.interval(distance: far.distance) {
                farPlayer.position = point(far.worldPosition)
                farPlayer.volume = FarCuePolicy.gain(distance: far.distance)
                noteRealSound(at: now)
                farPlayer.scheduleBuffer(farClick)
                if !farPlayer.isPlaying { farPlayer.play() }
                lastFarPulse = now
            }
        } else {
            farPlayer.stop()
            reportFarStatus(cells.contains(where: \.isActive)
                ? "Far sound: yielding to near LiDAR cues"
                : "Far sound: waiting for a fresh confirmed target")
        }
        for id in 0..<10 {
            // The mesh beep replaces the faint mid-range cell clicks, so only
            // one clear cue plays. Urgent near tones retain their original rules.
            if useMesh { silence(id); continue }
            guard let cell = cells.first(where: { $0.id == id && $0.isActive }),
                  let position = cell.worldPosition, let distance = cell.distance else {
                silence(id); continue
            }
            let player = players[id]
            player.position = point(position)
            player.volume = SoundDesign.volume(distance: distance)
            let toneIndex = cell.level == .head ? 0 : 1
            if distance < 0.5 {
                noteRealSound(at: now)
                if !looping[id] {
                    player.stop()
                    player.scheduleBuffer(continuous[toneIndex], at: nil, options: .loops)
                    player.play(); looping[id] = true; sounding[id] = true
                }
            } else {
                if looping[id] { silence(id) }
                if cadence.shouldPulse(cellID: id, distance: distance, now: now) {
                    noteRealSound(at: now)
                    player.scheduleBuffer(clicks[toneIndex])
                    if !player.isPlaying { player.play() }
                    sounding[id] = true
                }
            }
        }
        fillDemoGap(at: now)
    }

    private func silence(_ id: Int) {
        if sounding[id] { players[id].stop() }
        sounding[id] = false; looping[id] = false
    }
    private func silenceObstacles() { farPlayer.stop(); for id in 0..<10 { silence(id) } }
    private func point(_ p: SIMD3<Float>) -> AVAudio3DPoint { AVAudio3DPoint(x: p.x, y: p.y, z: p.z) }
}
