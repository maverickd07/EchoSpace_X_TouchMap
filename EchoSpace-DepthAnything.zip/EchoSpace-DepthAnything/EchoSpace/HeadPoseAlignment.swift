import Foundation
import simd

/// Horizontal head-turn alignment. No assumption about headphone X/Y mounting:
/// select a well-conditioned local axis, project its attitude onto gravity's
/// horizontal reference plane, and measure heading change from calibration.
/// Core Motion reference +Z is vertical; AR world +Y is vertical.
struct HeadPoseAlignment {
    private var localAxis: SIMD3<Float>?
    private var referenceHeading: SIMD3<Float>?
    private var cameraHeading: simd_quatf?
    var isCalibrated: Bool { cameraHeading != nil }

    static func normalized(_ q: simd_quatf) -> simd_quatf? {
        let n = simd_length(q.vector)
        guard q.vector.x.isFinite, q.vector.y.isFinite, q.vector.z.isFinite,
              q.vector.w.isFinite, n > 0.5, n < 1.5 else { return nil }
        return simd_normalize(q)
    }

    mutating func reset() { localAxis = nil; referenceHeading = nil; cameraHeading = nil }

    mutating func calibrate(camera: simd_float4x4, headphone: simd_quatf) -> Bool {
        guard let q = Self.normalized(headphone) else { return false }
        let forward = -SIMD3(camera[2].x, camera[2].y, camera[2].z)
        let horizontal = SIMD3(forward.x, 0, forward.z)
        guard simd_length(horizontal).isFinite, simd_length(horizontal) > 0.8 else { return false }
        let f = simd_normalize(horizontal), up = SIMD3<Float>(0, 1, 0)
        let right = simd_normalize(simd_cross(f, up))
        let axes = [SIMD3<Float>(1,0,0), SIMD3<Float>(0,1,0), SIMD3<Float>(0,0,1)]
        let axis = axes.min { abs(q.act($0).z) < abs(q.act($1).z) }!
        let heading = q.act(axis)
        localAxis = axis
        referenceHeading = simd_normalize(SIMD3(heading.x, heading.y, 0))
        cameraHeading = simd_quatf(simd_float3x3(columns: (right, up, -f)))
        return true
    }

    func orientation(headphone: simd_quatf) -> simd_quatf? {
        guard let axis = localAxis, let initial = referenceHeading, let base = cameraHeading,
              let q = Self.normalized(headphone) else { return nil }
        let rotated = q.act(axis)
        let horizontal = SIMD3(rotated.x, rotated.y, 0)
        // Extreme tilt cannot reliably supply heading. Fall back explicitly.
        guard simd_length(horizontal) > 0.5 else { return nil }
        let heading = simd_normalize(horizontal)
        let sine = simd_cross(initial, heading).z
        let cosine = simd_dot(initial, heading)
        let turn = atan2(sine, cosine)
        return simd_normalize(simd_quatf(angle: turn, axis: SIMD3(0,1,0)) * base)
    }

    static func listener(camera: simd_float4x4, headOrientation: simd_quatf?) -> simd_float4x4 {
        guard let headOrientation else { return camera }
        var transform = simd_float4x4(headOrientation)
        // Position is still approximated by the chest-mounted camera. Headphones
        // provide orientation, not a measured world-space head position.
        transform[3] = camera[3]
        return transform
    }
}

struct HeadphonePoseSample {
    let orientation: simd_quatf
    let timestamp: Double
    let angularSpeed: Double
    let source: Int
    func isFresh(at now: Double) -> Bool { now >= timestamp && now - timestamp < 0.35 }
}
