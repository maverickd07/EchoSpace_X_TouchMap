import Foundation

/// Units: radians/second and gravity-free acceleration in g.
/// Hysteresis avoids flapping; thresholds are prototype defaults for device tuning.
struct MotionStability {
    private(set) var isUnstable = false
    private var highSince: TimeInterval?
    private var calmSince: TimeInterval?

    mutating func update(rotation: Double, acceleration: Double, time: TimeInterval) -> Bool {
        let high = rotation > 2.8 || acceleration > 0.9
        let calm = rotation < 1.2 && acceleration < 0.35
        if high {
            calmSince = nil
            if highSince == nil { highSince = time }
            if time - highSince! >= 0.12 { isUnstable = true }
        } else {
            highSince = nil
            if calm {
                if calmSince == nil { calmSince = time }
                if time - calmSince! >= 0.9 { isUnstable = false }
            } else { calmSince = nil }
        }
        return isUnstable
    }
}
