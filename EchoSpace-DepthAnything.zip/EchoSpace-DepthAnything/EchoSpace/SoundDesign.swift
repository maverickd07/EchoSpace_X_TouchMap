import AVFoundation

/// Pure oscillator synthesis: no bundled audio files or network dependencies.
enum SoundDesign {
    static let sampleRate = 48_000.0
    static let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!

    static func pulseRate(distance: Float) -> Double {
        1 / ProximityRhythm.interval(distance: distance)
    }

    static func volume(distance: Float) -> Float {
        let d = min(3, max(0.5, distance))
        if d >= 2 { return 0.07 - (d - 2) * 0.025 }
        if d >= 1 { return 0.24 - (d - 1) * 0.17 }
        return 0.36 - (d - 0.5) * 0.24
    }

    /// A gentle but audible sustained beep; the old 12 ms click decay was easy
    /// to miss outdoors even though its buffer was nominally 60 ms long.
    static func farWarningTone(frequency: Double = 600) -> AVAudioPCMBuffer {
        let duration = 0.18
        let frames = AVAudioFrameCount(duration * sampleRate)
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frames)!
        buffer.frameLength = frames
        let samples = buffer.floatChannelData![0]
        for i in 0..<Int(frames) {
            let t = Double(i) / sampleRate
            let envelope = max(0, min(1, min(t / 0.015, (duration - t) / 0.04)))
            samples[i] = Float(sin(2 * .pi * frequency * t) * envelope * 0.5)
        }
        return buffer
    }

    static func tone(frequency: Double, duration: Double, click: Bool) -> AVAudioPCMBuffer {
        let frames = AVAudioFrameCount(duration * sampleRate)
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frames)!
        buffer.frameLength = frames
        let samples = buffer.floatChannelData![0]
        for i in 0..<Int(frames) {
            let t = Double(i) / sampleRate
            // Continuous buffers contain integer cycles and loop without a phase seam.
            let envelope = click ? min(1, t / 0.003) * exp(-t / 0.012) * min(1, (duration - t) / 0.004) : 1
            samples[i] = Float(sin(2 * .pi * frequency * t) * envelope * 0.5)
        }
        return buffer
    }
}

/// Retain cooldowns across active-cell changes: cell churn must not restart clicks.
struct ObstaclePulseCadence {
    private var lastPulse = [Int: TimeInterval]()
    private var lastDistantPulse = -Double.infinity

    mutating func shouldPulse(cellID: Int, distance: Float, now: TimeInterval) -> Bool {
        guard now.isFinite, distance.isFinite, distance >= 0.5, distance <= 3 else { return false }
        let interval = 1 / SoundDesign.pulseRate(distance: distance)
        guard now - (lastPulse[cellID] ?? -.infinity) >= interval else { return false }
        // Distant sources share a quiet budget even when the nearest cell changes.
        if distance >= 2 && now - lastDistantPulse < interval { return false }
        lastPulse[cellID] = now
        if distance >= 2 { lastDistantPulse = now }
        return true
    }
}


/// Shared distance curve for measured mesh, grid cells and camera estimates.
/// Interpolate intervals, with a one-second maximum even for far detections.
enum ProximityRhythm {
    static func interval(distance: Float) -> Double {
        let d = Double(min(3.6, max(0.5, distance)))
        if d >= 3 { return 0.9 + (d - 3) / 0.6 * 0.1 }
        if d >= 1 { return 0.4 + (d - 1) * 0.25 }
        return 0.1 + (d - 0.5) * 0.6
    }
}


/// Demo-only heartbeat budget. Actual audio refreshes the clock, so the
/// heartbeat fills gaps without layering over normal cues or resetting on frames.
struct DemoContinuityCadence {
    private var lastOutput = -Double.infinity
    mutating func noteOutput(at now: Double) {
        if now.isFinite { lastOutput = now }
    }
    mutating func shouldPulse(enabled: Bool, now: Double) -> Bool {
        guard enabled, now.isFinite, now - lastOutput >= 1 else { return false }
        lastOutput = now
        return true
    }
}
