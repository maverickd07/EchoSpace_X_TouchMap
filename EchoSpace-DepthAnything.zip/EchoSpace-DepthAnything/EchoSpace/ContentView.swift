import SwiftUI

struct ContentView: View {
    @StateObject private var controller = AppController()
    @Environment(\.scenePhase) private var scenePhase
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 5), count: 5)

    var body: some View {
        ScrollView {
            VStack(spacing: 22) {
                Text("EchoSpace").font(.largeTitle.bold()).accessibilityAddTraits(.isHeader)
                Text(controller.status).multilineTextAlignment(.center)
                ZStack(alignment: .topLeading) {
                    CameraSceneView(session: controller.cameraSession, surface: controller.surface,
                                    cells: controller.model.cells, surfaceCue: controller.surfaceCue, showPoints: controller.showPoints,
                                    showWireframe: controller.showWireframe,
                                    visible: controller.isRunning && controller.hasPose,
                                    revision: controller.surfaceRevision, onViewportChange: controller.setCameraViewport)
                    GeometryReader { geometry in
                        HStack(spacing: 0) {
                            Color.black.opacity(0.16)
                            Color.clear
                            Color.black.opacity(0.16)
                        }
                        Path { path in
                            for fraction in [1.0 / 3, 2.0 / 3] {
                                let x = geometry.size.width * fraction
                                path.move(to: CGPoint(x: x, y: 0))
                                path.addLine(to: CGPoint(x: x, y: geometry.size.height))
                            }
                        }.stroke(.yellow.opacity(0.85), style: StrokeStyle(lineWidth: 2, dash: [6, 4]))
                    }.allowsHitTesting(false).accessibilityHidden(true)
                    if !controller.isRunning {
                        Color.black
                        Text("Start to scan your surroundings")
                            .foregroundStyle(.white).frame(maxWidth: .infinity, maxHeight: .infinity)
                    }
                    VStack(alignment: .leading, spacing: 8) {
                        Text("LIVE SURFACES · 0–10 m").font(.caption.bold())
                        Text("RECORDING STABILITY v9").font(.caption2.bold())
                        if controller.demoContinuityEnabled {
                            Text(controller.demoToneActive ? "DEMO TONE · Not an obstacle alert" : "DEMO CONTINUITY ON")
                                .font(.caption.bold()).padding(5).background(.black.opacity(0.75), in: Capsule())
                        }
                        if let cue = controller.surfaceCue {
                            Text(String(format: "Center target: %.2f m", cue.distance))
                                .font(.caption.bold()).padding(5).background(.black.opacity(0.7), in: Capsule())
                        }
                        Text("Mesh beeps queued: \(controller.meshPulseCount)").font(.caption2)
                        Text("\(controller.surface.pointCloud.count.formatted()) surface points · recent 0.8 s")
                            .font(.caption.monospacedDigit())
                            .padding(5).background(.black.opacity(0.6), in: Capsule())
                        if controller.isUnstable {
                            Label("Movement detected · Scanning continues", systemImage: "exclamationmark.triangle.fill")
                                .font(.headline).padding(10).background(.orange, in: Capsule()).foregroundStyle(.black)
                        } else if controller.isRunning && !controller.hasPose {
                            Text("Waiting for reliable depth").font(.caption)
                        }
                        Spacer()
                        Text("Orange: sound target · Cyan: dense surface points")
                            .font(.caption2).padding(6).background(.black.opacity(0.6), in: Capsule())
                    }.padding(12).foregroundStyle(.white)
                }
                .frame(height: 360).clipShape(RoundedRectangle(cornerRadius: 20))
                HStack {
                    Toggle("Wireframe", isOn: $controller.showWireframe)
                    Toggle("Points", isOn: Binding(
                        get: { controller.showPoints || controller.showWireframe },
                        set: { controller.showPoints = $0 }))
                        .disabled(controller.showWireframe)
                }.font(.caption)
                VStack(alignment: .leading, spacing: 6) {
                    Toggle("Camera far preview (experimental)", isOn: $controller.farPreviewEnabled)
                    Text(controller.farStatus).font(.caption).foregroundStyle(.secondary)
                    Text(controller.farSoundStatus).font(.caption).foregroundStyle(.secondary)
                    Text("Output: \(controller.route.isEmpty ? "—" : controller.route)").font(.caption)
                    Text("Mesh cues use measured LiDAR. Under 1 m, urgent near cues take over. Camera estimates remain experimental.")
                        .font(.caption2).foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Toggle("Demo continuous sound", isOn: $controller.demoContinuityEnabled)
                    Text("A centered demo beep fills audio gaps once per second. It does not indicate an obstacle. Live obstacle cues take priority.")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Text("Middle third: early warning · Left/right: warn within 1 m").font(.caption).foregroundStyle(.secondary)
                if !controller.motionAvailable {
                    Text("Motion sensor unavailable. AR tracking checks remain active.")
                        .font(.caption).foregroundStyle(.orange)
                }
                Button {
                    if controller.isRunning { controller.stop() }
                    else { Task { await controller.start() } }
                } label: {
                    Text(controller.isRunning ? "Stop" : "Start")
                        .font(.system(size: 44, weight: .bold))
                        .frame(maxWidth: .infinity, minHeight: 110)
                        .foregroundStyle(.white)
                        .background(controller.isRunning ? Color.red : Color.blue, in: RoundedRectangle(cornerRadius: 28))
                }
                .disabled(controller.isStarting)
                .accessibilityHint("Starts or stops obstacle sound and the camera")

                VStack(alignment: .leading, spacing: 10) {
                    Text("DEPTH DEBUG · METERS").font(.caption.bold())
                    Text("Head · 1200 Hz").font(.caption)
                    LazyVGrid(columns: columns, spacing: 6) {
                        ForEach(controller.model.cells) { cell in
                            VStack(spacing: 4) {
                                Text(cell.distance.map { String(format: "%.2f", $0) } ?? "—")
                                    .font(.system(.body, design: .monospaced).bold())
                                Text(cell.isActive ? "ACTIVE" : " ").font(.system(size: 9, weight: .bold))
                            }
                            .frame(maxWidth: .infinity, minHeight: 55)
                            .background(cell.isActive ? Color.orange : Color.secondary.opacity(0.15), in: RoundedRectangle(cornerRadius: 8))
                            .foregroundStyle(cell.isActive ? Color.black : Color.primary)
                        }
                    }
                    Text("Body · 300 Hz").font(.caption)
                    if let nearest = controller.model.activeCells.first, let p = nearest.worldPosition {
                        Text(String(format: "Nearest world (m)\nx: %+.3f  y: %+.3f  z: %+.3f", p.x, p.y, p.z))
                            .font(.system(.caption, design: .monospaced))
                    } else {
                        Text("Nearest world: —").font(.caption.monospaced())
                    }
                    Text("Output: \(controller.route.isEmpty ? "—" : controller.route)").font(.caption)
                }
                // Continuously changing grid is for sighted judges; keep VoiceOver focused on controls.
                .accessibilityHidden(true)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Headphone / Camera Alignment").font(.headline)
                    Text(controller.headStatus).font(.caption)
                    Text("Wear your headphones. Face forward with the rear camera, hold steady, then tap Calibrate.")
                        .font(.caption).foregroundStyle(.secondary)
                    Button(controller.headCalibrated ? "Recalibrate" : "Calibrate Headphones & Camera") {
                        controller.calibrateHeadphones()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(!controller.canCalibrateHead)
                    if controller.headCalibrated {
                        Text(controller.headTurnText).font(.caption.monospacedDigit()).accessibilityHidden(true)
                        Button("Use Phone Direction") { controller.resetHeadCalibration() }
                            .buttonStyle(.bordered)
                    }
                    Text("Tracks left and right head turns. Looking up or down does not change the sound direction yet.")
                        .font(.caption2).foregroundStyle(.secondary)
                }

                Button("Axis Test") { controller.axisTest() }
                    .buttonStyle(.borderedProminent).controlSize(.large)
                    .disabled(!controller.isRunning || !controller.hasPose || controller.axisLabel != nil)
                    .accessibilityHint("Plays left, right, then ahead for two seconds each. Stay at the starting position.")
                Text(controller.axisLabel.map { "Axis test: \($0)" } ?? "Axis test: left → right → ahead, 2 seconds each")
                    .font(.footnote).multilineTextAlignment(.center)
                Text("Hold upright on your chest, rear camera facing ahead. Head/body labels describe image regions, not measured obstacle height.")
                    .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                Text("Prototype assistive cue. Keep using your cane or guide dog.")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .padding(24)
        }
        .alert("Do you need help?", isPresented: $controller.showHelpPrompt) {
            Button("Get Help") { controller.requestHelp() }
            Button("Not Now", role: .cancel) { }
        } message: {
            Text("Phone movement detected. Scanning and valid obstacle alerts continue. Choose Get Help to select a contact and send a help message.")
        }
        .sheet(isPresented: $controller.showHelpSheet) {
            HelpShareSheet()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .background { controller.stop(message: "Paused — tap Start to resume") }
        }
    }
}


/// Opens the system share UI; nothing is sent until the user chooses a recipient
/// and confirms in that app. No location or contact data is collected automatically.
private struct HelpShareSheet: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: ["I need help right now. Please contact me."], applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) { }
}
