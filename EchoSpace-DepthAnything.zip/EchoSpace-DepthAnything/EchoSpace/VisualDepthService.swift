import ARKit
import CoreML
import CoreImage
import QuartzCore

struct VisualDepthResult {
    let candidate: FarObstacle?
    let status: String
    let timestamp: Double
}

/// Owns a single inference in flight. No ARFrame is retained by the model queue.
/// The gate protects enable/generation/busy state across main, AR and model queues.
final class VisualDepthService {
    var onResult: ((VisualDepthResult) -> Void)?
    private let queue = DispatchQueue(label: "EchoSpace.visualDepth", qos: .utility)
    private let gate = NSLock()
    private var enabled = false
    private var generation = 0
    private var busy = false
    private var lastSubmission = -Double.infinity
    private let context = CIContext(options: [.cacheIntermediates: false])
    private var model: MLModel?
    private var loadError: String?
    private var confirmation = FarObstacleConfirmation()
    private var confirmationGeneration = -1

    func setEnabled(_ enabled: Bool) {
        gate.lock(); defer { gate.unlock() }
        guard self.enabled != enabled else { return }
        self.enabled = enabled
        generation += 1
        lastSubmission = -.infinity
    }

    private struct Sample { let raw: CGPoint; let meters: Float }
    private struct Capture {
        let image: CVPixelBuffer
        let samples: [Sample]
        let warningDisplay: CGAffineTransform
        let display: CGAffineTransform
        let content: CGRect // normalized model input, top-left coordinates
        let intrinsics: simd_float3x3
        let transform: simd_float4x4
        let portraitPose: simd_float4x4
        let resolution: CGSize
        let timestamp: Double
    }

    func submit(_ frame: ARFrame, viewportSize: CGSize) {
        gate.lock()
        guard enabled, !busy, frame.timestamp - lastSubmission >= 0.8 else { gate.unlock(); return }
        busy = true; lastSubmission = frame.timestamp
        let token = generation
        gate.unlock()
        // Render a private, small input now so ARKit can recycle its camera buffers.
        guard let capture = capture(frame, viewportSize: viewportSize) else {
            gate.lock(); busy = false; gate.unlock()
            return
        }
        queue.async { [weak self] in
            guard let self else { return }
            defer { self.gate.lock(); self.busy = false; self.gate.unlock() }
            self.gate.lock(); let valid = self.enabled && token == self.generation; self.gate.unlock()
            guard valid else { return }
            if self.confirmationGeneration != token {
                self.confirmation.reset(); self.confirmationGeneration = token
            }
            let result = autoreleasepool { self.predict(capture) }
            self.gate.lock(); let current = self.enabled && token == self.generation; self.gate.unlock()
            if current { self.onResult?(result) }
        }
    }

    private func capture(_ frame: ARFrame, viewportSize: CGSize) -> Capture? {
        guard case .normal = frame.camera.trackingState,
              let depth = frame.smoothedSceneDepth, let confidence = depth.confidenceMap else { return nil }
        guard let prepared = CameraDepthInput.prepare(frame.capturedImage, context: context) else { return nil }
        let map = depth.depthMap
        CVPixelBufferLockBaseAddress(map, .readOnly); CVPixelBufferLockBaseAddress(confidence, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(map, .readOnly); CVPixelBufferUnlockBaseAddress(confidence, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(map), let quality = CVPixelBufferGetBaseAddress(confidence) else { return nil }
        let dw = CVPixelBufferGetWidth(map), dh = CVPixelBufferGetHeight(map)
        let cw = CVPixelBufferGetWidth(confidence), ch = CVPixelBufferGetHeight(confidence)
        var samples: [Sample] = []
        for y in stride(from: 2, to: dh - 2, by: 4) {
            let row = base.advanced(by: y * CVPixelBufferGetBytesPerRow(map)).assumingMemoryBound(to: Float.self)
            let q = quality.advanced(by: (y * ch / dh) * CVPixelBufferGetBytesPerRow(confidence)).assumingMemoryBound(to: UInt8.self)
            for x in stride(from: 2, to: dw - 2, by: 4) {
                let d = row[x]
                guard q[x * cw / dw] == ARConfidenceLevel.high.rawValue, d.isFinite, d >= 0.5, d <= 4,
                      abs(row[x - 2] - d) < 0.1, abs(row[x + 2] - d) < 0.1 else { continue }
                samples.append(Sample(raw: CGPoint(x: (CGFloat(x) + 0.5) / CGFloat(dw),
                                                   y: (CGFloat(y) + 0.5) / CGFloat(dh)), meters: d))
            }
        }
        let size = frame.camera.imageResolution
        return Capture(image: prepared.image, samples: samples,
                       warningDisplay: frame.displayTransform(for: .portrait, viewportSize: viewportSize),
                       display: frame.displayTransform(for: .portrait, viewportSize: CGSize(width: size.height, height: size.width)),
                       content: prepared.content,
                       intrinsics: frame.camera.intrinsics, transform: frame.camera.transform,
                       portraitPose: simd_inverse(frame.camera.viewMatrix(for: .portrait)), resolution: size, timestamp: frame.timestamp)
    }

    private func predict(_ capture: Capture) -> VisualDepthResult {
        func unavailable(_ message: String) -> VisualDepthResult {
            confirmation.reset()
            return VisualDepthResult(candidate: nil, status: message, timestamp: capture.timestamp)
        }
        do {
            if let loadError { return unavailable(loadError) }
            if model == nil {
                guard let url = Bundle.main.url(forResource: "DepthAnythingV2SmallF16", withExtension: "mlmodelc") else {
                    loadError = "Far preview: model missing"; return unavailable(loadError!)
                }
                let config = MLModelConfiguration(); config.computeUnits = .all
                do { model = try MLModel(contentsOf: url, configuration: config) }
                catch { loadError = "Far preview: model could not load"; return unavailable(loadError!) }
            }
            let input = try MLDictionaryFeatureProvider(dictionary: ["image": MLFeatureValue(pixelBuffer: capture.image)])
            guard let output = try model?.prediction(from: input).featureValue(for: "depth")?.imageBufferValue else {
                return unavailable("Far preview: no model output")
            }
            guard CACurrentMediaTime() - capture.timestamp < 1.2 else { return unavailable("Far preview: inference delayed") }
            CVPixelBufferLockBaseAddress(output, .readOnly)
            defer { CVPixelBufferUnlockBaseAddress(output, .readOnly) }
            guard let base = CVPixelBufferGetBaseAddress(output) else { return unavailable("Far preview: output unavailable") }
            let format = CVPixelBufferGetPixelFormatType(output)
            guard format == kCVPixelFormatType_OneComponent16Half || format == kCVPixelFormatType_OneComponent32Float else {
                return unavailable("Far preview: unsupported depth format")
            }
            let ow = CVPixelBufferGetWidth(output), oh = CVPixelBufferGetHeight(output)
            func relative(_ portrait: CGPoint) -> Float {
                let x = min(ow - 1, max(0, Int((capture.content.minX + portrait.x * capture.content.width) * CGFloat(ow))))
                let y = min(oh - 1, max(0, Int((capture.content.minY + portrait.y * capture.content.height) * CGFloat(oh))))
                let row = base.advanced(by: y * CVPixelBufferGetBytesPerRow(output))
                return format == kCVPixelFormatType_OneComponent16Half
                    ? Float(Float16(bitPattern: row.assumingMemoryBound(to: UInt16.self)[x]))
                    : row.assumingMemoryBound(to: Float.self)[x]
            }
            let pairs = capture.samples.map { DepthPair(relative: relative($0.raw.applying(capture.display)), meters: $0.meters) }
            guard let fit = VisualDepthCalibration.fit(pairs) else { return unavailable("Far preview: waiting for reliable calibration") }
            let pose = capture.portraitPose
            let forward3 = -SIMD3(pose[2].x, pose[2].y, pose[2].z)
            guard abs(forward3.y) < 0.45, pose[1].y > 0.8 else { return unavailable("Far preview: hold phone upright") }
            let forward = simd_normalize(SIMD3(forward3.x, 0, forward3.z))
            let right = simd_cross(forward, SIMD3<Float>(0, 1, 0))
            let origin = SpatialGeometry.position(capture.transform)
            let inverseDisplay = capture.display.inverted()
            // Group adjacent image samples into small patches to reject isolated estimates.
            var patches: [Int: [FarObstacle]] = [:]
            for y in 0..<80 {
                for x in 0..<60 {
                    let portrait = CGPoint(x: (Double(x) + 0.5) / 60, y: (Double(y) + 0.5) / 80)
                    guard let depth = fit.meters(relative: relative(portrait)) else { continue }
                    let raw = portrait.applying(inverseDisplay)
                    let screen = raw.applying(capture.warningDisplay)
                    guard WarningZone.isCenter(x: screen.x), screen.y >= 0, screen.y <= 1 else { continue }
                    let world = SpatialGeometry.unproject(pixel: SIMD2(Float(raw.x * capture.resolution.width), Float(raw.y * capture.resolution.height)),
                                                          depth: depth, intrinsics: capture.intrinsics, cameraTransform: capture.transform)
                    let offset = world - origin
                    guard FarCuePolicy.inCorridor(offset, right: right, forward: forward), simd_length(offset) <= 10 else { continue }
                    patches[(y / 5) * 12 + x / 5, default: []].append(FarObstacle(worldPosition: world, distance: simd_length(offset), timestamp: capture.timestamp))
                }
            }
            let candidates = patches.values.compactMap { points -> FarObstacle? in
                guard points.count >= 8 else { return nil }
                let sorted = points.sorted { $0.distance < $1.distance }
                guard sorted[sorted.count * 3 / 4].distance - sorted[sorted.count / 4].distance < 0.8 else { return nil }
                return sorted[sorted.count / 2]
            }
            let candidate = candidates.min { $0.distance < $1.distance }
            let confirmed = confirmation.update(candidate)
            let status = confirmed.map { String(format: "Camera estimate ≈ %.1f m · experimental", $0.distance) }
                ?? (candidate == nil ? "Far preview: no confirmed target (not an all-clear)" : "Far preview: confirming target")
            return VisualDepthResult(candidate: confirmed, status: status, timestamp: capture.timestamp)
        } catch { return unavailable("Far preview: inference unavailable") }
    }
}
