import ARKit
import UIKit
import QuartzCore

struct DepthSnapshot {
    let cells: [ObstacleCell]
    let listenerTransform: simd_float4x4
    let trackingIsNormal: Bool
    let message: String
    var surface: SurfaceMesh = .empty
    var timestamp: TimeInterval = 0
    var hasDepthMeasurements = false
    var centerSurfacePoint: SIMD3<Float>?
    var warningCells: [ObstacleCell]?
}

final class DepthSampler: NSObject, ARSessionDelegate {
    let session = ARSession()
    var onSnapshot: ((DepthSnapshot) -> Void)?
    var onCameraFrame: ((ARFrame, CGSize) -> Void)?
    var onFailure: ((String) -> Void)?
    private let queue = DispatchQueue(label: "EchoSpace.depth", qos: .userInitiated)
    private var viewportSize = CGSize(width: 1, height: 1)
    func setViewportSize(_ size: CGSize) {
        guard size.width > 0, size.height > 0 else { return }
        queue.async { [weak self] in self?.viewportSize = size }
    }
    private var pointHistory = SurfacePointHistory()
    private var accumulateSurface = true
    private var startedAt = Double.infinity
    private var lastTimestamp: TimeInterval = -.infinity

    override init() {
        super.init()
        session.delegate = self
        session.delegateQueue = queue
    }

    func start() {
        queue.sync { lastTimestamp = -.infinity; startedAt = CACurrentMediaTime(); pointHistory.reset(); accumulateSurface = true }
        let configuration = ARWorldTrackingConfiguration()
        configuration.frameSemantics = .smoothedSceneDepth
        configuration.worldAlignment = .gravity
        session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    }

    func stop() {
        session.pause()
        queue.sync { startedAt = .infinity; pointHistory.reset() }
    }

    func setSurfaceAccumulationEnabled(_ enabled: Bool) {
        queue.async { [weak self] in
            self?.pointHistory.reset()
            self?.accumulateSurface = enabled
        }
    }

    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard frame.timestamp >= startedAt else { return }
        guard frame.timestamp - lastTimestamp >= 1.0 / 15.0 else { return }
        lastTimestamp = frame.timestamp
        // ARCamera.transform is sensor-landscape. This equivalent ARKit camera pose
        // has portrait +Y (phone top) and the SAME forward -Z and world origin.
        let portraitPose = simd_inverse(frame.camera.viewMatrix(for: .portrait))
        let trackingIsNormal: Bool
        switch frame.camera.trackingState {
        case .normal: trackingIsNormal = true
        case .limited: trackingIsNormal = false
        case .notAvailable:
            trackingIsNormal = false
            pointHistory.reset()
            onSnapshot?(DepthSnapshot(cells: .emptyGrid, listenerTransform: portraitPose,
                                     trackingIsNormal: false, message: "Scanning — waiting for camera tracking", timestamp: frame.timestamp))
            return
        }
        guard let depth = frame.smoothedSceneDepth, let confidence = depth.confidenceMap else {
            pointHistory.reset()
            onSnapshot?(DepthSnapshot(cells: .emptyGrid, listenerTransform: portraitPose,
                                     trackingIsNormal: false, message: "Waiting for confident LiDAR depth", timestamp: frame.timestamp))
            return
        }
        onCameraFrame?(frame, viewportSize)
        let map = depth.depthMap
        CVPixelBufferLockBaseAddress(map, .readOnly)
        CVPixelBufferLockBaseAddress(confidence, .readOnly)
        defer {
            CVPixelBufferUnlockBaseAddress(confidence, .readOnly)
            CVPixelBufferUnlockBaseAddress(map, .readOnly)
        }
        guard let depthBase = CVPixelBufferGetBaseAddress(map),
              let confidenceBase = CVPixelBufferGetBaseAddress(confidence) else { return }
        let width = CVPixelBufferGetWidth(map), height = CVPixelBufferGetHeight(map)
        let cw = CVPixelBufferGetWidth(confidence), ch = CVPixelBufferGetHeight(confidence)
        let depthStride = CVPixelBufferGetBytesPerRow(map)
        let confidenceStride = CVPixelBufferGetBytesPerRow(confidence)
        var intrinsics = frame.camera.intrinsics
        let sx = Float(width) / Float(frame.camera.imageResolution.width)
        let sy = Float(height) / Float(frame.camera.imageResolution.height)
        intrinsics[0].x *= sx; intrinsics[1].y *= sy
        intrinsics[2].x *= sx; intrinsics[2].y *= sy

        // Only cell assignment uses portrait image coordinates. Audio never uses
        // a column-to-pan lookup. Use the full portrait image without aspect-fill cropping.
        let portraitSize = CGSize(width: frame.camera.imageResolution.height,
                                  height: frame.camera.imageResolution.width)
        let display = frame.displayTransform(for: .portrait, viewportSize: portraitSize)
        let warningDisplay = frame.displayTransform(for: .portrait, viewportSize: viewportSize)
        var warningCells = ObstacleCell.emptyGrid
        var warningMinimum = [Float](repeating: .infinity, count: 10)
        var cells = ObstacleCell.emptyGrid
        var minimumDepth = [Float](repeating: .infinity, count: 10)
        let origin = SpatialGeometry.position(frame.camera.transform)
        // <= roughly 3,072 samples for a 256 x 192 map. No history accumulates.
        let step = max(4, Int(ceil(Double(max(width, height)) / 64)))
        let sampleColumns = (width + step - 1) / step
        let sampleRows = (height + step - 1) / step
        var surfacePoints = [SIMD3<Float>?](repeating: nil, count: sampleColumns * sampleRows)
        // Full 256 x 192 depth coverage; bound larger future buffers to ~49k samples.
        let cloudStep = max(1, Int(ceil(sqrt(Double(width * height) / 49_152))))
        var cloud: [SIMD3<Float>] = []
        cloud.reserveCapacity(min(width * height, 49_152))
        for y in 0..<height {
            let values = depthBase.advanced(by: y * depthStride).assumingMemoryBound(to: Float32.self)
            let cy = min(ch - 1, y * ch / height)
            let qualities = confidenceBase.advanced(by: cy * confidenceStride).assumingMemoryBound(to: UInt8.self)
            for x in 0..<width {
                let d = values[x]
                guard qualities[min(cw - 1, x * cw / width)] >= ARConfidenceLevel.medium.rawValue,
                      d.isFinite, d > 0 else { continue }
                let meshSample = x % step == 0 && y % step == 0
                let cloudSample = x % cloudStep == 0 && y % cloudStep == 0
                if d <= 4 && (meshSample || cloudSample) {
                    let world = SpatialGeometry.unproject(pixel: SIMD2(Float(x), Float(y)), depth: d,
                                                          intrinsics: intrinsics, cameraTransform: frame.camera.transform)
                    if meshSample { surfacePoints[(y / step) * sampleColumns + x / step] = world }
                    if cloudSample && cloud.count < 49_152 { cloud.append(world) }
                }
                let portrait = CGPoint(x: (CGFloat(x) + 0.5) / CGFloat(width),
                                       y: (CGFloat(y) + 0.5) / CGFloat(height)).applying(display)
                guard portrait.x >= 0, portrait.x <= 1, portrait.y >= 0, portrait.y <= 1 else { continue }
                let index = min(1, Int(portrait.y * 2)) * 5 + min(4, Int(portrait.x * 5))
                let point = SpatialGeometry.unproject(pixel: SIMD2(Float(x), Float(y)), depth: d,
                                                      intrinsics: intrinsics, cameraTransform: frame.camera.transform)
                let distance = simd_distance(origin, point)
                let screen = CGPoint(x: (CGFloat(x) + 0.5) / CGFloat(width),
                                     y: (CGFloat(y) + 0.5) / CGFloat(height)).applying(warningDisplay)
                if d < warningMinimum[index], WarningZone.allowsCell(x: screen.x, y: screen.y, distance: distance) {
                    warningMinimum[index] = d
                    warningCells[index].worldPosition = point
                    warningCells[index].distance = distance
                }
                if d < minimumDepth[index] {
                    minimumDepth[index] = d
                    cells[index].worldPosition = point
                    cells[index].distance = distance
                }
            }
        }
        var surface = SurfaceMesh.connect(points: surfacePoints, columns: sampleColumns, rows: sampleRows)
        // No confident measurements: do not display old samples as a current scan.
        if cloud.isEmpty { pointHistory.reset() }
        surface.pointCloud = accumulateSurface
            ? pointHistory.merge(cloud, timestamp: frame.timestamp) : cloud
        let centerPoint = surface.nearestTrianglePoint(to: origin) { point in
            let pixel = frame.camera.projectPoint(point, orientation: .portrait, viewportSize: self.viewportSize)
            return WarningZone.isCenter(x: pixel.x / self.viewportSize.width) &&
                pixel.y >= 0 && pixel.y <= self.viewportSize.height
        }
        onSnapshot?(DepthSnapshot(cells: cells, listenerTransform: portraitPose,
                                 trackingIsNormal: trackingIsNormal, message: trackingIsNormal ? "LiDAR active · 15 Hz · portrait" : "Scanning · tracking limited · measurements may drift",
                                 surface: surface,
                                 timestamp: frame.timestamp, hasDepthMeasurements: true, centerSurfacePoint: centerPoint, warningCells: warningCells))
    }

    func session(_ session: ARSession, didFailWithError error: Error) { onFailure?(error.localizedDescription) }
    func sessionWasInterrupted(_ session: ARSession) { onFailure?("AR session interrupted. Tap Start to restart.") }
}

private extension Array where Element == ObstacleCell {
    static var emptyGrid: [ObstacleCell] { ObstacleCell.emptyGrid }
}
