import CoreMotion
import QuartzCore
import simd

@MainActor
final class HeadphoneMotionMonitor {
    private let manager = CMHeadphoneMotionManager()
    private var running = false
    private var generation = 0
    private var watchdog: Timer?
    private var sample: HeadphonePoseSample?
    private var source: Int?
    private var lastStatus = ""
    private var streamStartedAt = -Double.infinity
    var onSample: ((HeadphonePoseSample) -> Void)?
    var onUnavailable: ((String) -> Void)?

    func start() {
        stop(); running = true
        streamStartedAt = CACurrentMediaTime()
        check()
        watchdog = Timer(timeInterval: 0.2, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.check() }
        }
        if let watchdog { RunLoop.main.add(watchdog, forMode: .common) }
    }

    func stop() {
        running = false; generation += 1
        watchdog?.invalidate(); watchdog = nil
        manager.stopDeviceMotionUpdates()
        sample = nil; source = nil; lastStatus = ""
    }

    private func unavailable(_ message: String) {
        sample = nil
        guard lastStatus != message else { return }
        lastStatus = message
        onUnavailable?(message)
    }

    private func check() {
        guard running else { return }
        let authorization = CMHeadphoneMotionManager.authorizationStatus()
        guard authorization != .denied && authorization != .restricted else {
            unavailable("Headphone motion permission unavailable · Using phone direction"); return
        }
        guard manager.isDeviceMotionAvailable else {
            unavailable("No supported head-tracking headphones detected · Using phone direction")
            if manager.isDeviceMotionActive { manager.stopDeviceMotionUpdates(); generation += 1 }
            return
        }
        if !manager.isDeviceMotionActive { beginStream() }
        let now = CACurrentMediaTime()
        if let sample, !sample.isFresh(at: now) {
            unavailable("Headphone data lost · Using phone direction. Please recalibrate")
        } else if sample == nil && now - streamStartedAt > 2 {
            unavailable("Waiting for headphone motion · Using phone direction")
        }
    }

    private func beginStream() {
        generation += 1
        let token = generation
        streamStartedAt = CACurrentMediaTime()
        manager.startDeviceMotionUpdates(to: .main) { [weak self] motion, error in
            MainActor.assumeIsolated {
                guard let self, self.running, self.generation == token else { return }
                guard let motion, error == nil else {
                    self.unavailable("Headphone motion error · Using phone direction. Please recalibrate"); return
                }
                let value = motion.attitude.quaternion
                guard let q = HeadPoseAlignment.normalized(simd_quatf(ix: Float(value.x), iy: Float(value.y), iz: Float(value.z), r: Float(value.w))) else {
                    self.unavailable("Invalid headphone orientation · Using phone direction"); return
                }
                let r = motion.rotationRate
                let fresh = HeadphonePoseSample(orientation: q, timestamp: motion.timestamp,
                    angularSpeed: sqrt(r.x*r.x + r.y*r.y + r.z*r.z), source: motion.sensorLocation.rawValue)
                guard fresh.isFresh(at: CACurrentMediaTime()) else {
                    self.unavailable("Headphone data delayed · Using phone direction. Please recalibrate"); return
                }
                if let previous = self.sample, fresh.timestamp <= previous.timestamp { return }
                if let source = self.source, source != fresh.source {
                    self.unavailable("Headphone sensor changed · Please recalibrate")
                }
                self.source = fresh.source; self.sample = fresh; self.lastStatus = ""
                self.onSample?(fresh)
            }
        }
    }
}
