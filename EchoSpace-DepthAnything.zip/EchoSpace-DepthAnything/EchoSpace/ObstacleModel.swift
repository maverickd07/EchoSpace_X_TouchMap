import Foundation
import simd

enum ObstacleLevel: String { case head, body }

struct ObstacleCell: Identifiable {
    let id: Int
    var worldPosition: SIMD3<Float>?
    var distance: Float?
    var level: ObstacleLevel { id < 5 ? .head : .body }
    var isActive = false

    static var emptyGrid: [ObstacleCell] {
        (0..<10).map { ObstacleCell(id: $0) }
    }
}

struct ObstacleModel {
    private(set) var cells = ObstacleCell.emptyGrid
    var activeCells: [ObstacleCell] { cells.filter(\.isActive).sorted { $0.distance! < $1.distance! } }

    mutating func update(_ samples: [ObstacleCell], warningSamples: [ObstacleCell]? = nil) {
        cells = samples.map { var cell = $0; cell.isActive = false; return cell }
        let eligible = warningSamples ?? samples
        let nearest = eligible.indices.filter {
            guard let d = eligible[$0].distance, eligible[$0].worldPosition != nil else { return false }
            return d.isFinite && d > 0 && d <= 3
        }.sorted {
            let a = eligible[$0].distance!, b = eligible[$1].distance!
            return a == b ? eligible[$0].id < eligible[$1].id : a < b
        }.prefix(2)
        for index in nearest {
            guard let displayIndex = cells.firstIndex(where: { $0.id == eligible[index].id }) else { continue }
            cells[displayIndex] = eligible[index]
            cells[displayIndex].isActive = true
        }
    }
}

enum SpatialGeometry {
    /// Intrinsics have been scaled to the depth buffer resolution. Depth is axial -Z,
    /// not radial range. Image +Y is down; ARKit camera +Y is up.
    static func unproject(pixel: SIMD2<Float>, depth: Float,
                          intrinsics k: simd_float3x3, cameraTransform: simd_float4x4) -> SIMD3<Float> {
        let camera = SIMD4<Float>((pixel.x - k[2].x) * depth / k[0].x,
                                  -(pixel.y - k[2].y) * depth / k[1].y, -depth, 1)
        let world = cameraTransform * camera
        return SIMD3(world.x, world.y, world.z)
    }

    static func position(_ transform: simd_float4x4) -> SIMD3<Float> {
        SIMD3(transform[3].x, transform[3].y, transform[3].z)
    }
}


/// Coordinates belong to the actual portrait preview after ARKit's aspect-fill
/// display transform, not raw sensor columns or the diagnostic 5x2 grid.
enum WarningZone {
    static func isCenter(x: Double) -> Bool {
        x.isFinite && x >= 1.0 / 3 && x <= 2.0 / 3
    }
    static func allowsCell(x: Double, y: Double, distance: Float) -> Bool {
        guard x.isFinite, y.isFinite, x >= 0, x <= 1, y >= 0, y <= 1,
              distance.isFinite, distance > 0 else { return false }
        return distance <= (isCenter(x: x) ? 3 : 1)
    }
}
