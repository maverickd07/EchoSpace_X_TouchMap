import CoreMotion

@MainActor
final class MotionMonitor {
    private let manager = CMMotionManager()
    private var stability = MotionStability()
    private var generation = 0
    var onChange: ((Bool) -> Void)?
    var onUnavailable: (() -> Void)?

    func start() {
        stop()
        guard manager.isDeviceMotionAvailable else { onUnavailable?(); return }
        let request = generation
        manager.deviceMotionUpdateInterval = 1.0 / 50
        manager.startDeviceMotionUpdates(to: .main) { [weak self] data, error in
            MainActor.assumeIsolated {
                guard let self, self.generation == request else { return }
                guard let data, error == nil else {
                    self.stop(); self.onUnavailable?(); return
                }
                let r = data.rotationRate, a = data.userAcceleration
                let previous = self.stability.isUnstable
                let unstable = self.stability.update(
                    rotation: sqrt(r.x*r.x + r.y*r.y + r.z*r.z),
                    acceleration: sqrt(a.x*a.x + a.y*a.y + a.z*a.z), time: data.timestamp)
                if previous != unstable { self.onChange?(unstable) }
            }
        }
    }

    func stop() {
        generation += 1
        manager.stopDeviceMotionUpdates()
        stability = MotionStability()
    }
}
