# EchoSpace model attribution

EchoSpace bundles the unmodified `DepthAnythingV2SmallF16.mlpackage` published by Apple:
https://huggingface.co/apple/coreml-depth-anything-v2-small

Pinned revision: `cfef6f6f2a70783dedc0bfae40cecbc2052285d3`.
File sizes and SHA-256 digests: `depth-model.json`.
License: Apache License 2.0, included in `DepthAnything-LICENSE.txt`.

Underlying research/model: **Depth Anything V2**, by Lihe Yang, Bingyi Kang,
Zilong Huang, Zhen Zhao, Xiaogang Xu, Jiashi Feng and Hengshuang Zhao.
https://github.com/DepthAnything/Depth-Anything-V2

Only the Small model is bundled. Other model sizes have different licensing.
Swift integration reference inspected:
https://github.com/huggingface/coreml-examples/tree/main/depth-anything-example

EchoSpace's calibration, corridor selection, lifecycle and audio integration are
local implementation code. No third-party Python or Swift application source is
executed or bundled. Camera frames stay on the phone; no inference server or API
key is used. The model produces relative depth; metric extrapolation added by
EchoSpace is experimental and is not a model-author or Apple accuracy guarantee.
