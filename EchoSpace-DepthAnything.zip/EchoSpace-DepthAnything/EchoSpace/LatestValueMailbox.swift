import Foundation

/// Producer replaces pending work instead of enqueueing large snapshots while
/// the main thread is occupied by recording, rendering or system UI.
final class LatestValueMailbox<Value> {
    private let lock = NSLock()
    private var pending: Value?
    private var scheduled = false
    /// True means the caller must schedule one consumer. False means one exists.
    func put(_ value: Value) -> Bool {
        lock.lock(); defer { lock.unlock() }
        pending = value
        guard !scheduled else { return false }
        scheduled = true
        return true
    }
    func take() -> Value? {
        lock.lock(); defer { lock.unlock() }
        let value = pending
        pending = nil; scheduled = false
        return value
    }
}
