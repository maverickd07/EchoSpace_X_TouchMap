"""Fetch the pinned Apple Core ML conversion; never runs downloaded source code."""
from pathlib import Path
import urllib.request, hashlib, json, os
ROOT = Path(__file__).resolve().parents[1]
REPO = 'apple/coreml-depth-anything-v2-small'
REVISION = 'cfef6f6f2a70783dedc0bfae40cecbc2052285d3'
PACKAGE = 'DepthAnythingV2SmallF16.mlpackage'
FILES = ['Manifest.json', 'Data/com.apple.CoreML/model.mlmodel', 'Data/com.apple.CoreML/weights/weight.bin']
manifest = json.loads((ROOT / 'ThirdParty/depth-model.json').read_text())
assert manifest['revision'] == REVISION
for relative in FILES:
    path = ROOT / 'EchoSpace/Models' / PACKAGE / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    url = f'https://huggingface.co/{REPO}/resolve/{REVISION}/{PACKAGE}/{relative}'
    request = urllib.request.Request(url, headers={'User-Agent': 'EchoSpace-model-fetch'})
    temporary = path.with_suffix(path.suffix + '.download')
    with urllib.request.urlopen(request, timeout=90) as response, temporary.open('wb') as output:
        while chunk := response.read(1024 * 1024): output.write(chunk)
    expected = manifest['files'][relative]
    if temporary.stat().st_size != expected['bytes'] or hashlib.sha256(temporary.read_bytes()).hexdigest() != expected['sha256']:
        temporary.unlink()
        raise RuntimeError(f'Model checksum mismatch: {relative}')
    os.replace(temporary, path)
    print(relative, path.stat().st_size, flush=True)

