import SwiftUI

@main
struct EchoSpaceApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}
