import AVFoundation
import Foundation
import simd

func close(_ a: SIMD3<Float>, _ b: SIMD3<Float>, _ label: String) {
    precondition(simd_distance(a, b) < 0.0001, label)
}
let k = simd_float3x3(columns: (SIMD3(100, 0, 0), SIMD3(0, 100, 0), SIMD3(50, 50, 1)))
let identity = matrix_identity_float4x4
close(SpatialGeometry.unproject(pixel: SIMD2(50, 50), depth: 2, intrinsics: k, cameraTransform: identity), SIMD3(0, 0, -2), "center is negative Z")
close(SpatialGeometry.unproject(pixel: SIMD2(60, 40), depth: 2, intrinsics: k, cameraTransform: identity), SIMD3(0.2, 0.2, -2), "image y flips")
var rotated = simd_float4x4(simd_quatf(angle: .pi / 2, axis: SIMD3(0, 0, 1)))
rotated[3] = SIMD4(4, 5, 6, 1)
close(SpatialGeometry.unproject(pixel: SIMD2(60, 40), depth: 2, intrinsics: k, cameraTransform: rotated), SIMD3(3.8, 5.2, 4), "rotate then translate")
var model = ObstacleModel()
var cells = ObstacleCell.emptyGrid
for (id, d) in [Float(3), 0.5, 0.49, 3.01, .nan, -1].enumerated() {
    cells[id].distance = d; cells[id].worldPosition = SIMD3(0, 0, -d)
}
model.update(cells)
precondition(model.activeCells.map(\.id) == [2, 1], "only nearest two valid ranges")
model.update([ObstacleCell(id: 0, worldPosition: SIMD3(0, 0, -3), distance: 3)])
precondition(model.activeCells.count == 1, "3 m inclusive")
model.update(ObstacleCell.emptyGrid)
precondition(model.activeCells.isEmpty, "missing depth silences")
precondition(abs(SoundDesign.pulseRate(distance: 3) - 1 / 0.9) < 0.0001)
precondition(SoundDesign.pulseRate(distance: 0.5) == 10)
let buffer = SoundDesign.tone(frequency: 300, duration: 0.1, click: false)
precondition(buffer.format.channelCount == 1 && buffer.frameLength == 4800)
precondition((0..<Int(buffer.frameLength)).allSatisfy { buffer.floatChannelData![0][$0].isFinite })
print("PASS: unprojection signs, rotated world coordinates, nearest-two selection, thresholds, pulse rates, mono synthesis")

let plane: [SIMD3<Float>?] = [SIMD3(0, 0, -1), SIMD3(0.05, 0, -1), SIMD3(0, 0.05, -1), SIMD3(0.05, 0.05, -1)]
let mesh = SurfaceMesh.connect(points: plane, columns: 2, rows: 2)
precondition(mesh.vertices.count == 4 && mesh.triangles.count == 6, "flat quad has two triangles")
var gap = plane; gap[0] = nil
precondition(SurfaceMesh.connect(points: gap, columns: 2, rows: 2).triangles.count == 3, "missing depth leaves a hole")
var edge = plane; edge[0] = SIMD3(0, 0, -2)
precondition(SurfaceMesh.connect(points: edge, columns: 2, rows: 2).triangles.count == 3, "never bridge a depth discontinuity")
precondition(SurfaceMesh.connect(points: [], columns: 0, rows: 0).vertices.isEmpty)
var stability = MotionStability()
for i in 0..<100 {
    precondition(!stability.update(rotation: 0.6, acceleration: 0.25, time: Double(i) * 0.02), "normal motion is quiet")
}
precondition(!stability.update(rotation: 4, acceleration: 0, time: 2), "single spike is not an alarm")
precondition(!stability.update(rotation: 0, acceleration: 0, time: 2.02))
_ = stability.update(rotation: 4, acceleration: 0, time: 3)
precondition(stability.update(rotation: 4, acceleration: 0, time: 3.14), "sustained rotation warns")
precondition(stability.update(rotation: 0, acceleration: 0, time: 3.2), "no premature recovery")
precondition(stability.update(rotation: 1.5, acceleration: 0.5, time: 4.2), "middle band does not clear warning")
_ = stability.update(rotation: 0, acceleration: 0, time: 4.3)
precondition(!stability.update(rotation: 0, acceleration: 0, time: 5.3), "recover after sustained calm")
_ = stability.update(rotation: 0, acceleration: 1.1, time: 6)
precondition(stability.update(rotation: 0, acceleration: 1.1, time: 6.14), "translation alone also warns")
// Repeat bounded mesh construction with deterministic holes to exercise indices.
for frame in 0..<500 {
    let samples: [SIMD3<Float>?] = (0..<(64 * 48)).map { i in
        (i + frame) % 11 == 0 ? nil : SIMD3(Float(i % 64) * 0.025, Float(i / 64) * 0.025, -2)
    }
    let surface = SurfaceMesh.connect(points: samples, columns: 64, rows: 48)
    precondition(surface.vertices.count <= 3072)
    precondition(surface.triangles.count <= 63 * 47 * 6)
    precondition(surface.triangles.allSatisfy { $0 >= 0 && Int($0) < surface.vertices.count })
}
print("PASS: surface holes/edges/index bounds over 500 frames; motion debounce, rotation, acceleration and recovery")

var history = SurfacePointHistory(lifetime: 0.8, capacity: 10)
let firstPoint = SIMD3<Float>(0, 0, -1)
let secondPoint = SIMD3<Float>(0.02, 0, -1)
precondition(history.merge([firstPoint], timestamp: 1).count == 1)
precondition(history.merge([firstPoint, secondPoint], timestamp: 1.1).count == 2, "merge viewpoints without duplicating identical samples")
let expired = history.merge([secondPoint], timestamp: 1.95)
precondition(expired == [secondPoint], "expire old surface instead of leaving a permanent ghost")
precondition(history.merge([SIMD3(.nan, 0, 0)], timestamp: 3).isEmpty, "ignore invalid samples and clear after a gap")
precondition(history.merge([firstPoint], timestamp: 1).count == 1, "timestamp restart resets history")
history.reset()
precondition(history.merge([], timestamp: 1.1).isEmpty)
var capped = SurfacePointHistory(lifetime: 0.8, capacity: 5)
precondition(capped.merge((0..<20).map { SIMD3(Float($0) * 0.02, 0, -1) }, timestamp: 1).count == 5)
let latest = SIMD3<Float>(4, 0, -1)
precondition(capped.merge([latest], timestamp: 1.1).contains(latest), "prefer recent points at capacity")
print("PASS: multi-frame cloud merge, deduplication, expiry, reset, invalid input, capacity and recency")


precondition(abs(SoundDesign.pulseRate(distance: 2) - 1.0 / 0.65) < 0.0001)
precondition(abs(SoundDesign.pulseRate(distance: 1) - 2.5) < 0.0001)
precondition(SoundDesign.volume(distance: 3) < 0.05)
precondition(SoundDesign.volume(distance: 1) > SoundDesign.volume(distance: 2) * 3)
var quietCadence = ObstaclePulseCadence()
precondition(quietCadence.shouldPulse(cellID: 0, distance: 3, now: 0))
precondition(!quietCadence.shouldPulse(cellID: 1, distance: 3, now: 0.1), "distant cell switch must not cause extra click")
precondition(!quietCadence.shouldPulse(cellID: 0, distance: 3, now: 0.5), "reactivation preserves cooldown")
precondition(quietCadence.shouldPulse(cellID: 0, distance: 3, now: 4))
precondition(quietCadence.shouldPulse(cellID: 1, distance: 0.5, now: 4.01), "near hazard bypasses distant budget")
precondition(!quietCadence.shouldPulse(cellID: 1, distance: 0.5, now: 4.05))
precondition(quietCadence.shouldPulse(cellID: 1, distance: 0.5, now: 4.12))
precondition(!quietCadence.shouldPulse(cellID: 3, distance: 3.1, now: 10))
var churn = ObstaclePulseCadence()
var distantClicks = 0
for i in 0..<1000 {
    if churn.shouldPulse(cellID: i % 10, distance: 2.5, now: Double(i) / 100) { distantClicks += 1 }
}
precondition(distantClicks >= 12 && distantClicks <= 14, "cell churn respects the shared 2.5 m interval")
print("PASS: quiet distant cadence/gain, cell-churn cooldown, and immediate near-obstacle priority")

// Known inverse-depth calibration with held-out points and some training outliers.
let calibrationPairs = (0..<300).map { i -> DepthPair in
    let d = 0.6 + Float(i % 57) / 56 * 3.4
    return DepthPair(relative: (1 / d - 0.02) / 0.08, meters: d)
}
let calibrated = VisualDepthCalibration.fit(calibrationPairs)!
precondition(abs(calibrated.meters(relative: (1 / 6.0 - 0.02) / 0.08)! - 6) < 0.01)
precondition(calibrated.meters(relative: -100) == nil)
precondition(calibrated.meters(relative: .nan) == nil)
precondition(calibrated.meters(relative: (1 / 11.0 - 0.02) / 0.08) == nil)
precondition(VisualDepthCalibration.fit(Array(repeating: DepthPair(relative: 3, meters: 2), count: 200)) == nil)
precondition(VisualDepthCalibration.fit(Array(calibrationPairs.prefix(20))) == nil)
let noisy = calibrationPairs.enumerated().map { i, p in
    DepthPair(relative: p.relative + (i % 11 == 1 ? 2 : 0), meters: p.meters)
}
precondition(VisualDepthCalibration.fit(noisy) != nil)
let uncorrelated = calibrationPairs.enumerated().map { i, p in DepthPair(relative: Float(i % 7), meters: p.meters) }
precondition(VisualDepthCalibration.fit(uncorrelated) == nil)
var confirmation = FarObstacleConfirmation()
let far1 = FarObstacle(worldPosition: SIMD3(0, 0, -6), distance: 6, timestamp: 10)
let far2 = FarObstacle(worldPosition: SIMD3(0, 0, -6.1), distance: 6.1, timestamp: 10.5)
precondition(confirmation.update(far1) == nil)
precondition(confirmation.update(far2) != nil)
precondition(confirmation.update(nil) == nil)
precondition(confirmation.update(far2) == nil)
confirmation.reset()
precondition(confirmation.update(far2) == nil)
precondition(!FarCuePolicy.allowed(far2, now: 12, hasNearObstacle: false))
precondition(!FarCuePolicy.allowed(far2, now: 10, hasNearObstacle: false))
precondition(!FarCuePolicy.allowed(far2, now: 11, hasNearObstacle: true))
precondition(FarCuePolicy.allowed(far2, now: 11, hasNearObstacle: false))
precondition(FarCuePolicy.interval(distance: 10) == FarCuePolicy.interval(distance: 4))
precondition(FarCuePolicy.gain(distance: 10) < FarCuePolicy.gain(distance: 4))
let corridorRight = SIMD3<Float>(1, 0, 0), corridorForward = SIMD3<Float>(0, 0, -1)
precondition(FarCuePolicy.inCorridor(SIMD3(0, 0, -6), right: corridorRight, forward: corridorForward))
precondition(!FarCuePolicy.inCorridor(SIMD3(0, -1.5, -6), right: corridorRight, forward: corridorForward))
precondition(!FarCuePolicy.inCorridor(SIMD3(2, 0, -6), right: corridorRight, forward: corridorForward))
precondition(!FarCuePolicy.inCorridor(SIMD3(0, 0, 6), right: corridorRight, forward: corridorForward))
print("PASS: relative-depth calibration, degeneracy/outliers, range/NaN rejection, temporal confirmation, stale-result/near priority, corridor floor/side rejection")

let softWarning = SoundDesign.farWarningTone()
precondition(softWarning.format.channelCount == 1)
precondition(softWarning.frameLength == AVAudioFrameCount(0.18 * SoundDesign.sampleRate))
func energy(_ buffer: AVAudioPCMBuffer) -> Double {
    let values = buffer.floatChannelData![0]
    return (0..<Int(buffer.frameLength)).reduce(0.0) { sum, i in
        precondition(values[i].isFinite && abs(values[i]) <= 0.5)
        return sum + Double(values[i] * values[i])
    }
}
let oldFarClick = SoundDesign.tone(frequency: 600, duration: 0.06, click: true)
precondition(energy(softWarning) > energy(oldFarClick) * 10, "gentle beep must last long enough to hear")
precondition(abs(softWarning.floatChannelData![0][0]) < 0.001)
precondition(abs(softWarning.floatChannelData![0][Int(softWarning.frameLength) - 1]) < 0.001)
precondition(FarCuePolicy.gain(distance: 3.3) > 0.07)
precondition(FarCuePolicy.gain(distance: 10) == 0.04)
precondition(abs(FarCuePolicy.interval(distance: 3.3) - 0.95) < 0.0001)
print("PASS: audible far beep duration/energy, smooth endpoints, moderate gain and sparse cadence")

var meshCueTest = SurfaceMesh(vertices: [SIMD3(0, 0, -3.6), SIMD3(0.1, 0, -3.6), SIMD3(0, 0.1, -3.6)], pointCloud: [SIMD3(0, 0, -0.2)], triangles: [0, 1, 2])
precondition(meshCueTest.nearestTrianglePoint(to: .zero) == SIMD3<Float>(0, 0, -3.6), "mesh at 3.6m must provide cue despite old 3m grid cutoff")
meshCueTest.triangles = []
precondition(meshCueTest.nearestTrianglePoint(to: .zero) == nil, "cloud history alone must not beep")
meshCueTest.triangles = [-1, 999]
precondition(meshCueTest.nearestTrianglePoint(to: .zero) == nil)
precondition(SurfaceMesh.empty.nearestTrianglePoint(to: .zero) == nil)
print("PASS: visible mesh beyond 3m supplies measured cue; history/empty/invalid indices cannot trigger")

// Regression: nearby ground/cells previously silenced a 3.6 m mesh cue.
precondition(MeshCuePolicy.usesMesh(timestamp: 10, now: 10.1, nearestActiveDistance: 2.8))
precondition(MeshCuePolicy.usesMesh(timestamp: 10, now: 10.1, nearestActiveDistance: 1))
precondition(MeshCuePolicy.usesMesh(timestamp: 10, now: 10.1, nearestActiveDistance: nil))
precondition(!MeshCuePolicy.usesMesh(timestamp: 10, now: 10.1, nearestActiveDistance: 0.9))
precondition(!MeshCuePolicy.usesMesh(timestamp: 10, now: 10.5, nearestActiveDistance: nil))
precondition(!MeshCuePolicy.usesMesh(timestamp: nil, now: 10.1, nearestActiveDistance: nil))
precondition(!MeshCuePolicy.usesMesh(timestamp: 11, now: 10.1, nearestActiveDistance: nil))
precondition(MeshCuePolicy.interval(distance: 3.6) < 1.5)
precondition(MeshCuePolicy.gain(distance: 3.6) > 0.14)
precondition(MeshCuePolicy.interval(distance: 2) < MeshCuePolicy.interval(distance: 3.6))
print("PASS: mid-range active cells cannot suppress mesh warning; urgent/stale data priority and clear cadence")


let rhythmCases: [(Float, Double)] = [(10, 1), (4, 1), (3.6, 1), (3, 0.9), (2, 0.65), (1, 0.4), (0.5, 0.1)]
for (distance, expected) in rhythmCases {
    precondition(abs(ProximityRhythm.interval(distance: distance) - expected) < 0.0001)
    precondition(MeshCuePolicy.interval(distance: distance) == FarCuePolicy.interval(distance: distance))
    precondition(abs(1 / SoundDesign.pulseRate(distance: distance) - expected) < 0.0001)
}
for i in 50..<1000 {
    let near = ProximityRhythm.interval(distance: Float(i) / 100)
    let far = ProximityRhythm.interval(distance: Float(i + 1) / 100)
    precondition(near <= far, "approaching must never slow the rhythm")
}
var oneSecondCadence = ObstaclePulseCadence()
precondition(oneSecondCadence.shouldPulse(cellID: 0, distance: 3, now: 0))
precondition(!oneSecondCadence.shouldPulse(cellID: 1, distance: 3, now: 0.85))
precondition(oneSecondCadence.shouldPulse(cellID: 1, distance: 3, now: 0.91), "old three-second distant lockout must not survive")
print("PASS: shared one-second maximum rhythm, distance endpoints, monotonic approach and updated cooldown")

precondition(WarningZone.isCenter(x: 1.0 / 3))
precondition(WarningZone.isCenter(x: 2.0 / 3))
precondition(!WarningZone.isCenter(x: 0.32) && !WarningZone.isCenter(x: 0.68))
precondition(WarningZone.allowsCell(x: 0.5, y: 0.5, distance: 2.9))
precondition(!WarningZone.allowsCell(x: 0.15, y: 0.5, distance: 2.9))
precondition(!WarningZone.allowsCell(x: 0.85, y: 0.5, distance: 1.01))
precondition(WarningZone.allowsCell(x: 0.15, y: 0.5, distance: 1))
precondition(WarningZone.allowsCell(x: 0.85, y: 0.5, distance: 0.6))
precondition(!WarningZone.allowsCell(x: -0.1, y: 0.5, distance: 0.6))
precondition(!WarningZone.allowsCell(x: 0.5, y: 1.1, distance: 0.6))
precondition(!WarningZone.allowsCell(x: .nan, y: 0.5, distance: 0.6))
// Raw landscape x is not left/right in portrait. Rotate, then crop for preview.
let portraitTransform = CGAffineTransform(a: 0, b: 1, c: -1, d: 0, tx: 1, ty: 0)
let screenCenter = CGPoint(x: 0.1, y: 0.5).applying(portraitTransform)
let screenSide = CGPoint(x: 0.5, y: 0.9).applying(portraitTransform)
precondition(WarningZone.isCenter(x: screenCenter.x))
precondition(!WarningZone.isCenter(x: screenSide.x))
var allSamples = ObstacleCell.emptyGrid
var eligibleSamples = ObstacleCell.emptyGrid
// A near but excluded side sample and a valid center sample can share a debug cell.
allSamples[1] = ObstacleCell(id: 1, worldPosition: SIMD3(-1, 0, -1.5), distance: 1.8)
eligibleSamples[1] = ObstacleCell(id: 1, worldPosition: SIMD3(0, 0, -2.8), distance: 2.8)
model.update(allSamples, warningSamples: eligibleSamples)
precondition(model.activeCells.count == 1 && model.activeCells[0].distance == 2.8)
model.update(allSamples, warningSamples: ObstacleCell.emptyGrid)
precondition(model.activeCells.isEmpty && model.cells[1].distance == 1.8, "side remains visible in debug but silent")
let zonedMesh = SurfaceMesh(vertices: [SIMD3(-2,0,-2), SIMD3(0,0,-3.6), SIMD3(2,0,-2)], triangles: [0,1,2])
precondition(zonedMesh.nearestTrianglePoint(to: .zero, accepting: { abs($0.x) < 0.5 }) == SIMD3<Float>(0,0,-3.6))
precondition(zonedMesh.nearestTrianglePoint(to: .zero, accepting: { _ in false }) == nil, "side-only mesh must not trigger early cue")
print("PASS: center-third boundaries, side 1m threshold, portrait mapping, independent debug/cue samples and mesh filtering")

// User acceptance scenarios, with fixed WORLD targets and separate camera/head yaw.
let noTurn = simd_quatf(angle: 0, axis: SIMD3<Float>(0,0,1))
let headLeft = simd_quatf(angle: .pi / 4, axis: SIMD3<Float>(0,0,1))
var headAlignment = HeadPoseAlignment()
precondition(headAlignment.calibrate(camera: identity, headphone: noTurn))
let headStraightWorld = headAlignment.orientation(headphone: noTurn)!
let headLeftWorld = headAlignment.orientation(headphone: headLeft)!
let cameraLeft = simd_float4x4(simd_quatf(angle: .pi / 4, axis: SIMD3<Float>(0,1,0)))
let leftTarget = SIMD3<Float>(-2,0,-2)
func listenerPoint(_ world: SIMD3<Float>, _ pose: simd_float4x4) -> SIMD3<Float> {
    let p = simd_inverse(pose) * SIMD4(world.x, world.y, world.z, 1)
    return SIMD3(p.x, p.y, p.z)
}
let independentPose = HeadPoseAlignment.listener(camera: cameraLeft, headOrientation: headStraightWorld)
precondition(listenerPoint(leftTarget, independentPose).x < -1.9, "phone-only left rotation must leave target on listener's LEFT")
let followedPose = HeadPoseAlignment.listener(camera: cameraLeft, headOrientation: headLeftWorld)
precondition(abs(listenerPoint(leftTarget, followedPose).x) < 0.0001, "head follows target: sound returns to front")
let headOnlyPose = HeadPoseAlignment.listener(camera: identity, headOrientation: headLeftWorld)
precondition(listenerPoint(SIMD3(0,0,-3), headOnlyPose).x > 2, "head-only left rotation: fixed front target moves RIGHT")
// Absolute headphone startup heading must cancel, including quaternion sign.
var offsetAlignment = HeadPoseAlignment()
let offset = simd_quatf(angle: 1.2, axis: SIMD3<Float>(0,0,1))
precondition(offsetAlignment.calibrate(camera: cameraLeft, headphone: offset))
let result = offsetAlignment.orientation(headphone: headLeft * offset)!
close(result.act(SIMD3(0,0,-1)), SIMD3(-1,0,0), "nonidentity camera/head calibration composition")
let signFlipped = simd_quatf(vector: -(headLeft * offset).vector)
close(offsetAlignment.orientation(headphone: signFlipped)!.act(SIMD3(0,0,-1)), result.act(SIMD3(0,0,-1)), "q and -q are the same attitude")
var translatedCamera = cameraLeft
translatedCamera[3] = SIMD4(4,2,7,1)
let translatedListener = HeadPoseAlignment.listener(camera: translatedCamera, headOrientation: headStraightWorld)
close(SpatialGeometry.position(translatedListener), SIMD3(4,2,7), "listener position follows camera translation only")
close(HeadPoseAlignment.listener(camera: cameraLeft, headOrientation: nil)[2].xyzForTest,
      cameraLeft[2].xyzForTest, "uncalibrated fallback preserves camera orientation")
headAlignment.reset()
precondition(!headAlignment.isCalibrated && headAlignment.orientation(headphone: noTurn) == nil)
precondition(!headAlignment.calibrate(camera: identity, headphone: simd_quatf(vector: SIMD4<Float>(repeating: .nan))))
let headSample = HeadphonePoseSample(orientation: noTurn, timestamp: 10, angularSpeed: 0, source: 1)
precondition(headSample.isFresh(at: 10.1) && !headSample.isFresh(at: 10.4) && !headSample.isFresh(at: 9))
print("PASS: phone-only left, head-follows-target, head-only left, offset calibration, quaternion sign, translation, reset and freshness")

extension SIMD4 where Scalar == Float {
    var xyzForTest: SIMD3<Float> { SIMD3(x,y,z) }
}

var demoContinuity = DemoContinuityCadence()
precondition(!demoContinuity.shouldPulse(enabled: false, now: 0))
precondition(demoContinuity.shouldPulse(enabled: true, now: 0))
precondition(!demoContinuity.shouldPulse(enabled: true, now: 0.5))
precondition(demoContinuity.shouldPulse(enabled: true, now: 1))
demoContinuity.noteOutput(at: 1.8)
precondition(!demoContinuity.shouldPulse(enabled: true, now: 2), "real obstacle pulse must defer heartbeat")
precondition(demoContinuity.shouldPulse(enabled: true, now: 2.81), "missing depth does not leave the demo silent")
precondition(!demoContinuity.shouldPulse(enabled: false, now: 4))
precondition(!demoContinuity.shouldPulse(enabled: true, now: .nan))
var demoOnly = DemoContinuityCadence()
var demoPulses = 0
for tick in 0..<1000 {
    if demoOnly.shouldPulse(enabled: true, now: Double(tick) / 100) { demoPulses += 1 }
}
precondition(demoPulses == 10, "ten seconds without measurements gives ten demo beeps, not an obstacle tone loop")
print("PASS: demo continuity through missing data, live sound priority, off switch and one-second budget")

// Simulate a blocked UI consumer: thousands of camera frames must schedule
// only one delivery, retaining the newest value rather than a task per frame.
let mailbox = LatestValueMailbox<Int>()
var scheduledDeliveries = 0
for frame in 0..<10000 { if mailbox.put(frame) { scheduledDeliveries += 1 } }
precondition(scheduledDeliveries == 1)
precondition(mailbox.take() == 9999)
precondition(mailbox.take() == nil)
precondition(mailbox.put(10000), "consumer must be rearmed after draining")
precondition(mailbox.take() == 10000)
DispatchQueue.concurrentPerform(iterations: 1000) { index in _ = mailbox.put(index) }
_ = mailbox.put(10001)
precondition(mailbox.take() == 10001, "last completed producer is retained after concurrent submissions")
precondition(mailbox.put(10002) && mailbox.take() == 10002)
print("PASS: stalled UI delivery coalesces 10,000 frames, concurrent producers retain latest data, consumer rearms")
